// Utility to store and retrieve user uploaded video permanently in browser IndexedDB
const DB_NAME = 'CaldCenterMediaDB';
const STORE_NAME = 'videos';
const VIDEO_KEY = 'cald_tour_video';
const VIDEO_NAME_KEY = 'cald_tour_video_name';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveTourVideo(file: File): Promise<string> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    
    store.put(file, VIDEO_KEY);
    store.put(file.name, VIDEO_NAME_KEY);

    tx.oncomplete = () => {
      const objectUrl = URL.createObjectURL(file);
      resolve(objectUrl);
    };
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadSavedTourVideo(): Promise<{ url: string; name: string } | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      
      const fileReq = store.get(VIDEO_KEY);
      const nameReq = store.get(VIDEO_NAME_KEY);

      tx.oncomplete = () => {
        const file = fileReq.result as Blob | undefined;
        const name = (nameReq.result as string) || 'فيديو جولة مركز CALD';
        if (file) {
          const url = URL.createObjectURL(file);
          resolve({ url, name });
        } else {
          resolve(null);
        }
      };
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('IndexedDB unavailable or failed', e);
    return null;
  }
}

export async function clearSavedTourVideo(): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.delete(VIDEO_KEY);
      store.delete(VIDEO_NAME_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('Could not clear video from IndexedDB', e);
  }
}
