export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  iconName: string;
  benefits: string[];
  color: string;
  isWide?: boolean;
}

export interface NeedItem {
  id: string;
  title: string;
  desc: string;
  category: string;
  iconName: string;
  targetCost?: string;
  importance: string;
}

export interface BranchInfo {
  id: string;
  name: string;
  coverage: string;
  phones: string[];
  locationDesc: string;
  workingHours: string;
}

export interface StatItem {
  id: string;
  value: string;
  label: string;
  sublabel?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'facilities' | 'sensory' | 'therapy' | 'activities';
  desc: string;
  imageUrl: string;
  tag: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'general' | 'services' | 'sponsorship' | 'registration';
}

export interface SupportOption {
  id: string;
  title: string;
  iconName: string;
  suggestedAmount?: string;
  impactNote: string;
}
