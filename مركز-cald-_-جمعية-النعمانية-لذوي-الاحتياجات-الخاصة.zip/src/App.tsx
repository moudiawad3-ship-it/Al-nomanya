import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { WhoWeServeSection } from './components/WhoWeServeSection';
import { ServicesSection } from './components/ServicesSection';
import { TourAndGallerySection } from './components/TourAndGallerySection';
import { NeedsAndProjectsSection } from './components/NeedsAndProjectsSection';
import { DonationSection } from './components/DonationSection';
import { BranchesAndContactSection } from './components/BranchesAndContactSection';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { AccessibilityToolbar } from './components/AccessibilityToolbar';
import { DonationModal } from './components/DonationModal';
import { VolunteerModal } from './components/VolunteerModal';
import { AssessmentModal } from './components/AssessmentModal';
import { ExportModal } from './components/ExportModal';

export default function App() {
  const [isDonateOpen, setIsDonateOpen] = useState(false);
  const [donatePreset, setDonatePreset] = useState<string | undefined>(undefined);
  const [isVolunteerOpen, setIsVolunteerOpen] = useState(false);
  const [isAssessmentOpen, setIsAssessmentOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  const handleOpenDonate = (presetTitle?: string) => {
    setDonatePreset(presetTitle);
    setIsDonateOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FCFDFC] text-[#17282B] font-['Almarai'] antialiased flex flex-col selection:bg-[#2E93A0]/20 selection:text-[#0F3A42]">
      
      {/* Accessibility Floating Toolkit */}
      <AccessibilityToolbar />

      {/* Main Header Navigation */}
      <Navbar 
        onOpenDonate={() => handleOpenDonate()}
        onOpenAssessment={() => setIsAssessmentOpen(true)}
        onOpenVolunteer={() => setIsVolunteerOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <HeroSection 
          onOpenDonate={() => handleOpenDonate('كفالة طفل')}
          onOpenAssessment={() => setIsAssessmentOpen(true)}
        />

        <AboutSection />

        <WhoWeServeSection 
          onOpenAssessment={() => setIsAssessmentOpen(true)}
        />

        <ServicesSection 
          onOpenAssessment={() => setIsAssessmentOpen(true)}
          onOpenDonate={() => handleOpenDonate()}
        />

        <TourAndGallerySection />

        <NeedsAndProjectsSection 
          onOpenDonate={() => handleOpenDonate('مشروع تطوير')}
        />

        <DonationSection 
          onOpenDonateModal={(title) => handleOpenDonate(title)}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
        />

        <BranchesAndContactSection 
          onOpenDonate={() => handleOpenDonate()}
          onOpenAssessment={() => setIsAssessmentOpen(true)}
        />

        <FAQSection />
      </main>

      {/* Institutional Footer */}
      <Footer 
        onOpenDonate={() => handleOpenDonate()}
        onOpenAssessment={() => setIsAssessmentOpen(true)}
        onOpenVolunteer={() => setIsVolunteerOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Modals */}
      <DonationModal 
        isOpen={isDonateOpen}
        onClose={() => setIsDonateOpen(false)}
        presetTarget={donatePreset}
      />

      <VolunteerModal 
        isOpen={isVolunteerOpen}
        onClose={() => setIsVolunteerOpen(false)}
      />

      <AssessmentModal 
        isOpen={isAssessmentOpen}
        onClose={() => setIsAssessmentOpen(false)}
      />

      <ExportModal 
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

    </div>
  );
}
