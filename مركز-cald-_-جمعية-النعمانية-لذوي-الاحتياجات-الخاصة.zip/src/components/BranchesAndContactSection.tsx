import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  Check, 
  Copy, 
  MessageSquare, 
  PhoneCall, 
  Building2, 
  ExternalLink,
  ShieldCheck,
  Heart
} from 'lucide-react';
import { BRANCHES_DATA } from '../data/contentData';

interface ContactSectionProps {
  onOpenDonate: () => void;
  onOpenAssessment: () => void;
}

export const BranchesAndContactSection: React.FC<ContactSectionProps> = ({ 
  onOpenDonate,
  onOpenAssessment 
}) => {
  const [copiedPhone, setCopiedPhone] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formMessage, setFormMessage] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPhone(text);
    setTimeout(() => setCopiedPhone(null), 2500);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSuccess(true);
    setTimeout(() => {
      setFormSuccess(false);
      setFormName('');
      setFormPhone('');
      setFormSubject('');
      setFormMessage('');
    }, 4000);
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-[#0F3A42] to-[#0A262C] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 text-[#E7B96A] font-['Cairo'] font-bold text-xs mb-3 border border-white/15">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>لنتشارك الأثر</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            التواصل والفروع
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#DDEFEF] font-medium leading-relaxed">
            نعمل في مركز CALD على تطوير خدماتنا وتعزيز حضورنا المجتمعي، وبناء بيئة أكثر دعماً للأطفال والأهالي في عكار والشمال. يساهم تواصلكم ودعمكم اليوم في صناعة فرصة أفضل لمستقبلهم.
          </p>
        </div>

        {/* Branches Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          
          {/* Branch 1: Minyeh */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl p-7 sm:p-8 border border-white/15 shadow-xl flex flex-col justify-between hover:border-[#E7B96A]/50 transition-all text-right">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#E7B96A]/20 text-[#E7B96A] flex items-center justify-center">
                  <Building2 className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold font-['Cairo'] bg-white/10 text-[#E7B96A] px-3 py-1 rounded-full border border-white/15">
                  الفرع الإقليمي الجديد
                </span>
              </div>

              <h3 className="font-['Cairo'] text-2xl font-bold text-white mb-2 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#E7B96A]" />
                فرع المنية
              </h3>

              <p className="text-sm text-[#BFE0E0] mb-6 leading-relaxed">
                يخدم المنطقة الحيوية الممتدة من طرابلس وحتى العبدة ومحيطها بالكامل.
              </p>

              <div className="space-y-3 bg-black/20 p-4 rounded-2xl border border-white/10 mb-6">
                <div className="flex items-center justify-between text-xs text-[#DDEFEF]">
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#E7B96A]" /> أوقات الدوام:
                  </span>
                  <span className="font-semibold">الإثنين – الجمعة: 8:00 ص – 3:00 ب.ظ</span>
                </div>
              </div>
            </div>

            {/* Direct Phone Dial Button */}
            <div className="pt-4 border-t border-white/15 flex flex-wrap items-center justify-between gap-3">
              <a
                href="tel:76801069"
                className="inline-flex items-center gap-2 bg-[#B9862F] hover:bg-[#E7B96A] hover:text-[#0F3A42] text-white px-5 py-2.5 rounded-full text-sm font-bold font-['Cairo'] transition-all shadow-md"
              >
                <Phone className="w-4 h-4" />
                <span>اتصال مباشر: 76801069</span>
              </a>

              <div className="flex items-center gap-2">
                <a
                  href="https://wa.me/96176801069"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-full bg-[#25D366]/20 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-colors"
                  title="مراسلة عبر واتساب"
                >
                  <MessageSquare className="w-4 h-4" />
                </a>

                <button
                  onClick={() => copyToClipboard('76801069')}
                  className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors text-xs flex items-center gap-1"
                  title="نسخ الرقم"
                >
                  {copiedPhone === '76801069' ? <Check className="w-4 h-4 text-[#6FAF52]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

          </div>

          {/* Branch 2: Halba - Akkar */}
          <div className="bg-white/5 backdrop-blur-md rounded-3xl p-7 sm:p-8 border border-white/15 shadow-xl flex flex-col justify-between hover:border-[#E7B96A]/50 transition-all text-right">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#2E93A0]/20 text-[#2E93A0] flex items-center justify-center">
                  <Building2 className="w-6 h-6" />
                </div>
                <span className="text-xs font-bold font-['Cairo'] bg-[#B9862F] text-white px-3 py-1 rounded-full shadow-xs">
                  المقر الرئيسي (300 م²)
                </span>
              </div>

              <h3 className="font-['Cairo'] text-2xl font-bold text-white mb-2 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#E7B96A]" />
                فرع حلبا — عكار
              </h3>

              <p className="text-sm text-[#BFE0E0] mb-4 leading-relaxed">
                يخدم جميع بلدات وقرى عكار، الجومة، الدريب، والسهل مع صفوف وملاعب وغرف علاجية.
              </p>

              {/* Three Phone Numbers */}
              <div className="space-y-2 mb-6">
                {[
                  { num: '78913443', label: '78/913443' },
                  { num: '70120915', label: '70/120915' },
                  { num: '26695920', label: '26/695920 (أرضي)' },
                ].map((item) => (
                  <div key={item.num} className="flex items-center justify-between bg-black/20 px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                    <a href={`tel:${item.num}`} className="flex items-center gap-2 text-white hover:text-[#E7B96A] font-bold font-['Cairo']">
                      <Phone className="w-3.5 h-3.5 text-[#E7B96A]" />
                      <span>{item.label}</span>
                    </a>
                    <button
                      onClick={() => copyToClipboard(item.num)}
                      className="text-gray-400 hover:text-white p-1"
                      title="نسخ"
                    >
                      {copiedPhone === item.num ? <Check className="w-3.5 h-3.5 text-[#6FAF52]" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-white/15 flex items-center justify-between">
              <a
                href="tel:78913443"
                className="inline-flex items-center gap-2 bg-[#2E93A0] hover:bg-[#1E7B88] text-white px-5 py-2 rounded-full text-xs font-bold font-['Cairo'] transition-all shadow-md"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال بالمقر الرئيسي</span>
              </a>

              <a
                href="https://wa.me/96178913443"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-[#25D366]/20 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-colors"
                title="واتساب المقر الرئيسي"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>

          </div>

        </div>

        {/* Official Email and Fast Contact Form */}
        <div className="bg-white/5 backdrop-blur-md rounded-3xl p-8 sm:p-10 border border-white/15 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Email Info Column */}
            <div className="lg:col-span-5 text-right space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#E7B96A]/20 text-[#E7B96A] flex items-center justify-center">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="font-['Cairo'] text-2xl font-bold text-white">
                البريد الإلكتروني الرسمي
              </h3>
              <p className="text-sm text-[#BFE0E0] leading-relaxed">
                نستقبل استفساراتكم واقتراحات الشراكة المؤسسية عبر البريد الإلكتروني الرسمي للمركز:
              </p>
              
              <a 
                href="mailto:Cald2018@hotmail.com" 
                className="inline-flex items-center gap-3 bg-white/10 hover:bg-white/20 text-white px-5 py-3 rounded-2xl border border-white/20 text-base font-bold font-mono transition-colors"
              >
                <Mail className="w-5 h-5 text-[#E7B96A]" />
                <span>Cald2018@hotmail.com</span>
              </a>

              <div className="pt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={onOpenDonate}
                  className="bg-[#B9862F] hover:bg-[#E7B96A] hover:text-[#0F3A42] text-white font-['Cairo'] font-bold text-xs sm:text-sm px-6 py-3 rounded-full transition-all shadow-md"
                >
                  كن شريكاً في دعم أطفال عكار والشمال
                </button>
              </div>
            </div>

            {/* Quick Contact Form */}
            <div className="lg:col-span-7 bg-white text-[#17282B] p-6 sm:p-8 rounded-2xl shadow-xl text-right">
              <h4 className="font-['Cairo'] font-bold text-lg text-[#0F3A42] mb-1">
                إرسال رسالة مباشرة لإدارة المركز
              </h4>
              <p className="text-xs text-[#455B63] mb-4">
                سنقوم بالرد عليكم في أسرع وقت ممكن.
              </p>

              {formSuccess ? (
                <div className="bg-[#EAF3F3] p-4 rounded-xl text-center border border-[#2E93A0]/30 text-xs font-bold text-[#0F3A42] flex items-center justify-center gap-2">
                  <Check className="w-4 h-4 text-[#6FAF52]" />
                  <span>تم إرسال رسالتكم بنجاح. شكراً لاهتمامكم وتواصلكم!</span>
                </div>
              ) : (
                <form onSubmit={handleSendMessage} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-[#0F3A42] font-['Cairo'] mb-1">الاسم الكامل:</label>
                      <input
                        type="text"
                        required
                        value={formName}
                        onChange={(e) => setFormName(e.target.value)}
                        placeholder="الاسم الكريم"
                        className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-[#0F3A42] font-['Cairo'] mb-1">رقم الهاتف:</label>
                      <input
                        type="tel"
                        required
                        value={formPhone}
                        onChange={(e) => setFormPhone(e.target.value)}
                        placeholder="رقم الهاتف"
                        className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs text-left focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#0F3A42] font-['Cairo'] mb-1">الموضوع:</label>
                    <input
                      type="text"
                      required
                      value={formSubject}
                      onChange={(e) => setFormSubject(e.target.value)}
                      placeholder="استفسار، كفالة، تسجيل، تعاون..."
                      className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#0F3A42] font-['Cairo'] mb-1">الرسالة:</label>
                    <textarea
                      required
                      rows={3}
                      value={formMessage}
                      onChange={(e) => setFormMessage(e.target.value)}
                      placeholder="تفاصيل رسالتكم..."
                      className="w-full px-3 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors shadow-md"
                  >
                    <Send className="w-3.5 h-3.5 text-[#E7B96A]" />
                    <span>إرسال الرسالة الآن</span>
                  </button>
                </form>
              )}
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
