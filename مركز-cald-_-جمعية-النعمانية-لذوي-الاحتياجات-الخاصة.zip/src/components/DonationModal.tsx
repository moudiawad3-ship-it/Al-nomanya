import React, { useState } from 'react';
import { 
  X, 
  Heart, 
  Check, 
  Sparkles, 
  Receipt, 
  Phone, 
  CreditCard, 
  Building, 
  ShieldCheck,
  Send,
  DollarSign
} from 'lucide-react';
import { DONATION_TIERS } from '../data/contentData';

interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetTarget?: string;
}

export const DonationModal: React.FC<DonationModalProps> = ({ 
  isOpen, 
  onClose,
  presetTarget 
}) => {
  const [selectedTier, setSelectedTier] = useState<string>('session');
  const [customAmount, setCustomAmount] = useState<string>('50');
  const [donorName, setDonorName] = useState<string>('');
  const [donorPhone, setDonorPhone] = useState<string>('');
  const [dedicatedCause, setDedicatedCause] = useState<string>(presetTarget || 'كفالة جلسات علاجية');
  const [paymentMethod, setPaymentMethod] = useState<'whish' | 'omt' | 'bank' | 'cash'>('whish');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const resetForm = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E1E9E9] text-right animate-in zoom-in-95 duration-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#B9862F]/15 text-[#B9862F] flex items-center justify-center">
              <Heart className="w-6 h-6 fill-current" />
            </div>
            <div>
              <h3 className="font-['Cairo'] text-xl font-bold text-[#0F3A42]">
                مساهمة وكفالة في مركز CALD
              </h3>
              <p className="text-xs text-[#455B63]">
                جمعية النعمانية لذوي الاحتياجات الخاصة — عكار والشمال
              </p>
            </div>
          </div>
          <button
            onClick={resetForm}
            className="text-gray-400 hover:text-gray-700 p-2 rounded-xl hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          /* Confirmation View */
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#6FAF52]/20 text-[#6FAF52] flex items-center justify-center mx-auto mb-2 animate-bounce">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <h4 className="font-['Cairo'] text-2xl font-black text-[#0F3A42]">
              جزاكم الله كل خير، {donorName || 'فاعل الخير'}
            </h4>
            <p className="text-sm text-[#455B63] leading-relaxed max-w-sm mx-auto">
              تم تسجيل رغبتكم الكريمة في دعم: <strong className="text-[#0F3A42]">"{dedicatedCause}"</strong>. سيتواصل معكم منسق التبرعات في الجمعية عبر الرقم <strong>{donorPhone}</strong> لتأكيد الإيصال الرسمي وتفاصيل التحويل.
            </p>

            <div className="bg-[#F4FAFA] p-4 rounded-2xl border border-[#E1E9E9] text-xs text-right space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">رقم المرجع:</span>
                <span className="font-mono font-bold text-[#0F3A42]">CALD-{Math.floor(100000 + Math.random() * 900000)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">طريقة التحويل المفضلة:</span>
                <span className="font-bold text-[#B9862F] uppercase">{paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">للتواصل المباشر الفوري:</span>
                <span className="font-bold text-[#0F3A42]">76801069 / 78913443</span>
              </div>
            </div>

            <button
              onClick={resetForm}
              className="w-full py-3 rounded-full bg-[#0F3A42] text-white font-['Cairo'] font-bold text-sm hover:bg-[#14535D] transition-colors mt-4"
            >
              إغلاق ومتابعة
            </button>
          </div>
        ) : (
          /* Form View */
          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Tiers Selector */}
            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-2">
                اختر نوع الكفالة أو المساهمة:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DONATION_TIERS.slice(0, 4).map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => {
                      setSelectedTier(tier.id);
                      setDedicatedCause(tier.title);
                      if (tier.id === 'session') setCustomAmount('25');
                      if (tier.id === 'monthly') setCustomAmount('120');
                      if (tier.id === 'annual') setCustomAmount('1200');
                    }}
                    className={`p-3 rounded-2xl text-right border transition-all text-xs font-['Cairo'] ${
                      selectedTier === tier.id
                        ? 'bg-[#EAF3F3] border-[#2E93A0] text-[#0F3A42] ring-2 ring-[#2E93A0]/30 font-bold'
                        : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-[#0F3A42]">{tier.title}</span>
                      <span className="text-[#B9862F] font-black">{tier.suggestedAmount}</span>
                    </div>
                    <p className="text-[10px] text-gray-500 line-clamp-1">{tier.impactNote}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1.5">
                المبلغ المراد التبرع به ($ بالدولار الأمريكي أو ما يعادله):
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  min="1"
                  required
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-left font-bold text-base text-[#0F3A42] focus:ring-2 focus:ring-[#2E93A0] focus:outline-none pl-10"
                  placeholder="المبلغ"
                />
                <DollarSign className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
              </div>
            </div>

            {/* Cause Selection */}
            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1.5">
                تخصيص المساهمة لبند محدد:
              </label>
              <select
                value={dedicatedCause}
                onChange={(e) => setDedicatedCause(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs font-semibold text-[#17282B] focus:ring-2 focus:ring-[#2E93A0] focus:outline-none bg-white font-['Cairo']"
              >
                <option value="كفالة جلسات علاجية">كفالة جلسات علاجية (نطق / نفسي / إشغالي)</option>
                <option value="كفالة شهرية شاملة لطفل">كفالة شهرية شاملة لطفل محتاج</option>
                <option value="كفالة سنوية كاملة لطفل">كفالة سنوية كاملة لطفل</option>
                <option value="تجهيز غرفة علاج فيزيائي">مشروع تجهيز غرفة العلاج الفيزيائي</option>
                <option value="المساهمة في مشروع المصعد">مشروع مصعد الأمان لأصحاب الإعاقة الحركية</option>
                <option value="ألواح تفاعلية وحواسيب">مشروع الألواح التفاعلية والتعليم البصري</option>
                <option value="أجهزة تكييف وتدفئة">مشروع أجهزة التدفئة والتكييف</option>
                <option value="تأهيل المدخل والمنحدر">مشروع تأهيل المدخل والمنحدر الآمن</option>
                <option value="مساهمة عامة في تشغيل المركز">مساهمة عامة في تشغيل وتدفئة المركز</option>
              </select>
            </div>

            {/* Donor info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  الاسم الكامل / فاعل خير:
                </label>
                <input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="فاعل خير أو اسمكم الكريم"
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  رقم الهاتف للتواصل والوصل:
                </label>
                <input
                  type="tel"
                  value={donorPhone}
                  onChange={(e) => setDonorPhone(e.target.value)}
                  required
                  placeholder="مثال: 76801069 أو رقم دولي"
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs text-left focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-2">
                طريقة التبرع أو التحويل المناسبة لك:
              </label>
              <div className="grid grid-cols-4 gap-2 text-center text-xs font-bold font-['Cairo']">
                {[
                  { id: 'whish', label: 'Whish Money' },
                  { id: 'omt', label: 'OMT / Cash' },
                  { id: 'bank', label: 'تحويل بنكي' },
                  { id: 'cash', label: 'في المركز' },
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id as any)}
                    className={`py-2 px-1 rounded-xl border transition-all text-xs ${
                      paymentMethod === m.id
                        ? 'bg-[#0F3A42] text-white border-[#0F3A42] shadow-xs'
                        : 'bg-[#F4FAFA] text-gray-700 border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Guarantee note */}
            <div className="bg-[#EAF3F3] p-3 rounded-xl border border-[#2E93A0]/30 flex items-center gap-2 text-[11px] text-[#0F3A42]">
              <ShieldCheck className="w-4 h-4 text-[#6FAF52] shrink-0" />
              <span>يتم تزويدكم بإيصال استلام رسمي وتقارير أثر دورية مع صيانة خصوصية الطفل.</span>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-gray-800 font-['Cairo']"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full bg-[#B9862F] hover:bg-[#9E7024] text-white font-['Cairo'] font-bold text-sm shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>تأكيد تسجيل المساهمة</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
