import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Sparkles, 
  Lock, 
  Eye, 
  Video,
  Upload,
  Link as LinkIcon,
  AlertCircle,
  CheckCircle2,
  Trash2,
  FolderOpen,
  Camera
} from 'lucide-react';
import { GALLERY_DATA } from '../data/contentData';
import { GalleryItem } from '../types';
import { saveTourVideo, loadSavedTourVideo, clearSavedTourVideo } from '../utils/videoStorage';

interface PresetVideo {
  id: string;
  title: string;
  category: string;
  src: string;
  poster: string;
  duration: string;
  desc: string;
}

const PRESET_VIDEOS: PresetVideo[] = [
  {
    id: 'v1',
    title: 'جلسة تنمية المهارات والألعاب التعليمية',
    category: 'تعليم وتدخل مبكر',
    src: 'https://assets.mixkit.co/videos/preview/mixkit-little-girl-playing-with-educational-toys-41846-large.mp4',
    poster: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80',
    duration: '0:35',
    desc: 'نموذج لجلسات التدخل الفردي واستخدام الوسائل الحسية والتربوية المحفزة لتنمية التركيز.',
  },
  {
    id: 'v2',
    title: 'أنشطة اللعب الحركي وبناء المكعبات',
    category: 'علاج إشغالي وحركي',
    src: 'https://assets.mixkit.co/videos/preview/mixkit-boy-arranging-colorful-building-blocks-41848-large.mp4',
    poster: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?auto=format&fit=crop&w=800&q=80',
    duration: '0:28',
    desc: 'تمارين تناسق اليد والعين، والتركيز على إتمام المهمات الحركية الدقيقة.',
  },
  {
    id: 'v3',
    title: 'ورش التعبير الفني والرسم العلاجي',
    category: 'فنون وتواصل غير لفظي',
    src: 'https://assets.mixkit.co/videos/preview/mixkit-child-drawing-with-colored-pencils-39870-large.mp4',
    poster: 'https://images.unsplash.com/photo-1596495578065-6e0763fa1178?auto=format&fit=crop&w=800&q=80',
    duration: '0:30',
    desc: 'بيئة مرحة لتفريغ الطاقات وتطوير التعبير اللوني والشعوري للأطفال.',
  },
];

export const TourAndGallerySection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);
  
  // Video state
  const [selectedVideoId, setSelectedVideoId] = useState<string>('v1');
  const [activeVideoSrc, setActiveVideoSrc] = useState<string>(PRESET_VIDEOS[0].src);
  const [activeVideoPoster, setActiveVideoPoster] = useState<string>(PRESET_VIDEOS[0].poster);
  const [youtubeEmbedId, setYoutubeEmbedId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [inputUrl, setInputUrl] = useState('');
  const [videoError, setVideoError] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [hasSavedLocalVideo, setHasSavedLocalVideo] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Check and load saved video on mount
  useEffect(() => {
    async function initSavedVideo() {
      const saved = await loadSavedTourVideo();
      if (saved) {
        setActiveVideoSrc(saved.url);
        setSelectedVideoId('local-saved');
        setUploadedFileName(saved.name);
        setHasSavedLocalVideo(true);
      }
    }
    initSavedVideo();
  }, []);

  // Extract Youtube ID if provided
  const extractYoutubeId = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const handleSelectPreset = (video: PresetVideo) => {
    setSelectedVideoId(video.id);
    setYoutubeEmbedId(null);
    setActiveVideoSrc(video.src);
    setActiveVideoPoster(video.poster);
    setVideoError(false);
    setUploadedFileName(null);
    setIsPlaying(false);
    setProgress(0);
  };

  const handleApplyCustomUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;

    const ytId = extractYoutubeId(inputUrl.trim());
    if (ytId) {
      setYoutubeEmbedId(ytId);
      setActiveVideoSrc('');
      setSelectedVideoId('custom-yt');
    } else {
      setYoutubeEmbedId(null);
      setActiveVideoSrc(inputUrl.trim());
      setSelectedVideoId('custom-url');
    }
    setShowUrlInput(false);
    setVideoError(false);
    setIsPlaying(false);
  };

  const processVideoFile = async (file: File) => {
    try {
      const objectUrl = await saveTourVideo(file);
      setYoutubeEmbedId(null);
      setActiveVideoSrc(objectUrl);
      setSelectedVideoId('uploaded');
      setUploadedFileName(file.name || 'فيديو جولة مركز CALD');
      setHasSavedLocalVideo(true);
      setVideoError(false);
      setSaveSuccessMsg(true);
      setTimeout(() => setSaveSuccessMsg(false), 4000);
      
      setIsPlaying(true);
      if (videoRef.current) {
        videoRef.current.load();
        videoRef.current.play().catch(() => setIsPlaying(false));
      }
    } catch (err) {
      console.error('Error saving video to IndexedDB:', err);
      // Fallback
      const url = URL.createObjectURL(file);
      setActiveVideoSrc(url);
      setSelectedVideoId('uploaded');
      setUploadedFileName(file.name);
      setIsPlaying(true);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processVideoFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('video/')) {
      processVideoFile(file);
    }
  };

  const handleRemoveLocalVideo = async () => {
    await clearSavedTourVideo();
    setHasSavedLocalVideo(false);
    setUploadedFileName(null);
    handleSelectPreset(PRESET_VIDEOS[0]);
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().then(() => {
          setIsPlaying(true);
          setVideoError(false);
        }).catch((err) => {
          console.error("Video play error:", err);
          setIsPlaying(false);
        });
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const current = videoRef.current.currentTime;
      const total = videoRef.current.duration || 1;
      setCurrentTime(current);
      setProgress((current / total) * 100);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newProgress = parseFloat(e.target.value);
    setProgress(newProgress);
    if (videoRef.current && duration) {
      videoRef.current.currentTime = (newProgress / 100) * duration;
    }
  };

  const toggleFullscreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      }
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const filteredGallery = activeCategory === 'all' 
    ? GALLERY_DATA 
    : GALLERY_DATA.filter(item => item.category === activeCategory);

  return (
    <section id="tour-gallery" className="py-20 bg-[#F4FAFA] border-y border-[#E1E9E9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <Video className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>جولة واقعية مصوّرة</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            جولة داخل مركز CALD في حلبا
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            استكشف أروقة المركز، الممرات المزينة بالزهور وشجرة الفراشات، وقاعات التأهيل الحركي المجهزة بالأرجوحة والحصائر التفاعلية.
          </p>
        </div>

        {/* Video Tour Feature Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-20">
          
          {/* Video Player Column */}
          <div className="lg:col-span-6 flex flex-col items-center">
            
            {/* Phone/Frame Wrapper with Drag & Drop */}
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`relative w-full max-w-sm sm:max-w-md bg-[#0F2226] p-3.5 rounded-[36px] shadow-2xl border-4 transition-all duration-300 ${
                isDragging ? 'border-[#B9862F] scale-102 ring-4 ring-[#B9862F]/40' : 'border-[#17282B]'
              }`}
            >
              
              {/* Speaker Notch */}
              <div className="w-20 h-4 bg-[#17282B] rounded-full mx-auto mb-2 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-[#2E93A0]/40" />
              </div>

              {/* Video/Embed Container */}
              <div className="relative rounded-2xl overflow-hidden aspect-[9/16] bg-black group">
                
                {youtubeEmbedId ? (
                  /* YouTube Iframe Embed */
                  <iframe
                    src={`https://www.youtube.com/embed/${youtubeEmbedId}?autoplay=1&rel=0`}
                    title="CALD Tour Video"
                    className="w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  /* HTML5 Video Element */
                  <div className="relative w-full h-full">
                    <video
                      ref={videoRef}
                      src={activeVideoSrc}
                      poster={activeVideoPoster}
                      className="w-full h-full object-cover cursor-pointer"
                      playsInline
                      onClick={togglePlay}
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                      onTimeUpdate={handleTimeUpdate}
                      onLoadedMetadata={handleLoadedMetadata}
                      onError={() => {
                        setVideoError(true);
                        setIsPlaying(false);
                      }}
                    />

                    {/* Drag Over Overlay */}
                    {isDragging && (
                      <div className="absolute inset-0 bg-[#0F3A42]/90 backdrop-blur-xs flex flex-col items-center justify-center text-white z-30 p-4 text-center">
                        <Upload className="w-12 h-12 text-[#E7B96A] animate-bounce mb-2" />
                        <span className="font-['Cairo'] font-bold text-sm">أفلت ملف الفيديو هنا لتشغيله وحفظه فوراً</span>
                      </div>
                    )}

                    {/* Video Error Banner */}
                    {videoError && (
                      <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-6 text-center text-white z-20">
                        <AlertCircle className="w-10 h-10 text-[#D2665A] mb-3" />
                        <h4 className="font-['Cairo'] font-bold text-sm mb-1">تعذر تشغيل هذا الرابط</h4>
                        <p className="text-xs text-gray-300 mb-4">يمكنك اختيار ملف الفيديو الخاص بك من جهازك أو تشغيل المقطع النموذجي.</p>
                        <div className="flex flex-col gap-2 w-full max-w-xs">
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            className="bg-[#2E93A0] hover:bg-[#134A54] text-white px-4 py-2 rounded-xl text-xs font-['Cairo'] font-bold flex items-center justify-center gap-1.5"
                          >
                            <Upload className="w-4 h-4" />
                            <span>اختيار فيديو المركز من جهازي</span>
                          </button>
                          <button
                            onClick={() => handleSelectPreset(PRESET_VIDEOS[0])}
                            className="bg-white/20 hover:bg-white/30 text-white px-4 py-1.5 rounded-xl text-xs font-['Cairo']"
                          >
                            تشغيل المقطع البديل
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Video Controls Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 flex flex-col justify-between p-4 pointer-events-none">
                      
                      {/* Top Bar */}
                      <div className="flex items-center justify-between text-white text-xs font-bold font-['Cairo'] pointer-events-auto">
                        <span className="bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/20 flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-[#6FAF52] animate-pulse" />
                          <span>{hasSavedLocalVideo ? 'فيديو المركز المرفوع' : 'جولة مصوّرة داخلية'}</span>
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button 
                            onClick={toggleMute}
                            className="p-2 rounded-full bg-black/50 backdrop-blur-md text-white hover:bg-black/80 transition-colors"
                            aria-label={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
                            title={isMuted ? 'تشغيل الصوت' : 'كتم الصوت'}
                          >
                            {isMuted ? <VolumeX className="w-4 h-4 text-[#D2665A]" /> : <Volume2 className="w-4 h-4 text-[#6FAF52]" />}
                          </button>
                          <button 
                            onClick={toggleFullscreen}
                            className="p-2 rounded-full bg-black/50 backdrop-blur-md text-white hover:bg-black/80 transition-colors"
                            aria-label="ملء الشاشة"
                            title="ملء الشاشة"
                          >
                            <Maximize2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Center Big Play Button */}
                      <div className="flex items-center justify-center pointer-events-auto">
                        <button
                          onClick={togglePlay}
                          className={`w-16 h-16 rounded-full bg-[#B9862F]/90 hover:bg-[#E7B96A] text-white flex items-center justify-center shadow-2xl transform transition-all hover:scale-110 focus:outline-none backdrop-blur-xs ${
                            isPlaying ? 'opacity-0 hover:opacity-100' : 'opacity-100 scale-100'
                          }`}
                          aria-label={isPlaying ? 'إيقاف الفيديو' : 'تشغيل الفيديو'}
                        >
                          {isPlaying ? (
                            <Pause className="w-7 h-7 fill-current" />
                          ) : (
                            <Play className="w-7 h-7 fill-current translate-x-0.5" />
                          )}
                        </button>
                      </div>

                      {/* Bottom Controls Bar */}
                      <div className="text-white text-right space-y-2 pointer-events-auto">
                        
                        {/* Progress slider */}
                        <div className="flex items-center gap-2 text-[10px] font-mono text-gray-300">
                          <span>{formatTime(currentTime)}</span>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={progress || 0}
                            onChange={handleSeek}
                            className="flex-1 h-1.5 bg-white/30 rounded-lg appearance-none cursor-pointer accent-[#B9862F]"
                          />
                          <span>{formatTime(duration)}</span>
                        </div>

                        {/* Title details */}
                        <div className="flex items-center justify-between">
                          <div className="text-right">
                            <div className="text-xs font-bold font-['Cairo'] text-white truncate max-w-[200px]">
                              {uploadedFileName || 'جولة أروقة وقاعات مركز CALD'}
                            </div>
                            <div className="text-[10px] text-gray-300">حلبا — عكار والشمال</div>
                          </div>

                          <button
                            onClick={togglePlay}
                            className="p-1.5 rounded-full bg-white/20 text-white hover:bg-white/40"
                          >
                            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                          </button>
                        </div>

                      </div>

                    </div>
                  </div>
                )}

              </div>

            </div>

            {/* Saved Notification */}
            {saveSuccessMsg && (
              <div className="w-full max-w-sm sm:max-w-md mt-3 bg-[#6FAF52]/15 border border-[#6FAF52] text-[#0F3A42] p-2.5 rounded-xl text-xs font-bold font-['Cairo'] flex items-center gap-2 text-right animate-in fade-in slide-in-from-bottom-2">
                <CheckCircle2 className="w-4 h-4 text-[#6FAF52] shrink-0" />
                <span>تم حفظ الفيديو بنجاح في متصفحك وسيعمل تلقائياً عند فتح الموقع!</span>
              </div>
            )}

            {/* Main Action Bar for Video Source */}
            <div className="w-full max-w-sm sm:max-w-md mt-4 space-y-2.5">
              
              {/* Direct 1-Click File Selector */}
              <div className="bg-white p-3.5 rounded-2xl border border-[#2E93A0]/30 shadow-sm text-right space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-['Cairo'] text-[#0F3A42] flex items-center gap-1.5">
                    <FolderOpen className="w-4 h-4 text-[#B9862F]" />
                    <span>فيديو جولة المركز الخاص بك:</span>
                  </span>
                  {hasSavedLocalVideo && (
                    <button
                      onClick={handleRemoveLocalVideo}
                      className="text-[10px] text-[#D2665A] hover:underline flex items-center gap-1 font-bold"
                      title="حذف الفيديو المحفوظ والعودة للنماذج"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>إلغاء</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#0F3A42] hover:bg-[#14535D] text-white text-xs font-bold font-['Cairo'] flex items-center justify-center gap-2 transition-all shadow-sm hover:shadow"
                  >
                    <Upload className="w-4 h-4 text-[#E7B96A]" />
                    <span>{hasSavedLocalVideo ? 'تغيير ملف الفيديو' : 'اختيار ملف الفيديو من جهازك'}</span>
                  </button>

                  <button
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="py-2.5 px-3 rounded-xl bg-[#EAF3F3] hover:bg-[#D5E8E8] text-[#0F3A42] text-xs font-bold font-['Cairo'] flex items-center justify-center gap-1.5 transition-colors border border-[#2E93A0]/20"
                    title="إضافة رابط يوتيوب أو رابط مباشر"
                  >
                    <LinkIcon className="w-3.5 h-3.5 text-[#B9862F]" />
                    <span>رابط خارجي</span>
                  </button>
                </div>

                <p className="text-[10px] text-[#455B63] leading-relaxed">
                  💡 يمكنك اختيار ملف الفيديو من هاتفك أو حاسوبك (أو سحبه وإفلاته داخل إطار الهاتف أعلاه).
                </p>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/mp4,video/quicktime,video/webm,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              {/* External URL Input Modal/Dropdown */}
              {showUrlInput && (
                <form onSubmit={handleApplyCustomUrl} className="bg-white p-3 rounded-2xl border border-[#2E93A0] shadow-md text-right space-y-2 animate-in fade-in duration-200">
                  <label className="block text-[11px] font-bold text-[#0F3A42] font-['Cairo']">
                    ألصق رابط فيديو من YouTube أو رابط مباشر (MP4):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="url"
                      required
                      value={inputUrl}
                      onChange={(e) => setInputUrl(e.target.value)}
                      placeholder="https://www.youtube.com/watch?v=..."
                      className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-gray-300 text-left focus:outline-none focus:ring-2 focus:ring-[#2E93A0]"
                    />
                    <button
                      type="submit"
                      className="bg-[#0F3A42] hover:bg-[#14535D] text-white px-3 py-1.5 rounded-xl text-xs font-bold font-['Cairo']"
                    >
                      تطبيق
                    </button>
                  </div>
                </form>
              )}

              {/* Sample Preset Selector */}
              <div className="pt-1">
                <span className="block text-[10px] font-bold text-[#455B63] mb-1.5 text-right font-['Cairo']">
                  أو شاهد نماذج من الجلسات العلاجية:
                </span>
                <div className="grid grid-cols-3 gap-1.5">
                  {PRESET_VIDEOS.map((vid, idx) => (
                    <button
                      key={vid.id}
                      onClick={() => handleSelectPreset(vid)}
                      className={`p-2 rounded-xl text-center border transition-all text-xs font-['Cairo'] ${
                        selectedVideoId === vid.id
                          ? 'bg-[#0F3A42] text-white border-[#0F3A42] font-bold shadow-xs'
                          : 'bg-white text-[#455B63] border-[#E1E9E9] hover:bg-[#EAF3F3]'
                      }`}
                    >
                      <div className="text-[10px] font-bold truncate">نموذج {idx + 1}</div>
                      <div className="text-[9px] opacity-80 truncate">{vid.category}</div>
                    </button>
                  ))}
                </div>
              </div>

            </div>

          </div>

          {/* Video Description & Key Facility Highlights */}
          <div className="lg:col-span-6 space-y-6 text-right">
            
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#E1E9E9] shadow-sm">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EAF3F3] text-[#0F3A42] text-xs font-bold font-['Cairo'] mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#B9862F]" />
                <span>المقر الرئيسي — حلبا عكار</span>
              </div>
              
              <h3 className="font-['Cairo'] text-2xl font-bold text-[#0F3A42] mb-3">
                بيئة رحبة صُممت لتبهج الطفل وتطمئن الأسرة
              </h3>
              
              <p className="text-sm sm:text-base text-[#455B63] leading-relaxed mb-5">
                تتجول في هذا الفيديو في أروقة مركز CALD وقاعاته التأهيلية في حلبا؛ حيث تُبرز المشاهد التفاصيل المبهجة التي تمنح الطفل شعوراً بالألفة والأمان:
              </p>

              {/* Visual Breakdown of what's in the actual video */}
              <div className="space-y-3 mb-6">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9]">
                  <div className="w-7 h-7 rounded-full bg-[#B9862F]/20 text-[#B9862F] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    🌸
                  </div>
                  <div>
                    <h4 className="font-['Cairo'] font-bold text-xs text-[#0F3A42]">ممر الاستقبال والزهور المعلقة</h4>
                    <p className="text-[11px] text-[#455B63]">زينات ملونة على السقف وشجرة الفراشات واليرقة التفاعلية لتشجيع الطفل على الخطوات الأولى بحماس.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9]">
                  <div className="w-7 h-7 rounded-full bg-[#2E93A0]/20 text-[#2E93A0] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    🎪
                  </div>
                  <div>
                    <h4 className="font-['Cairo'] font-bold text-xs text-[#0F3A42]">قاعة التكامل الحسي والأرجوحة المعلقة</h4>
                    <p className="text-[11px] text-[#455B63]">مجهزة بنفق المرور الحركي، أرجوحة التوازن، والحصائر الأرضية المبطنة لتدريب التناسق العضلي والعصبي.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9]">
                  <div className="w-7 h-7 rounded-full bg-[#6FAF52]/20 text-[#6FAF52] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    🎨
                  </div>
                  <div>
                    <h4 className="font-['Cairo'] font-bold text-xs text-[#0F3A42]">غرف الجلسات الفردية وشجرة الحروف</h4>
                    <p className="text-[11px] text-[#455B63]">طاولات تعليمية مخصصة، ركن الرسم والتعبير، وجداريات الأشكال والألوان لتعزيز التركيز والنطق.</p>
                  </div>
                </div>
              </div>

              {/* Strict Privacy Protection Note */}
              <div className="bg-[#EAF3F3] p-4 sm:p-5 rounded-2xl border border-[#2E93A0]/30 flex items-start gap-3.5">
                <Lock className="w-5 h-5 text-[#134A54] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-['Cairo'] font-bold text-xs sm:text-sm text-[#0F3A42] mb-1">
                    التزام مطلق بخصوصية وكرامة الأطفال
                  </h4>
                  <p className="text-xs text-[#0F3A42]/90 leading-relaxed">
                    حفاظاً على خصوصية الأطفال ووفق المعايير المهنية، تُعرض في الوسائط العامة مرافق وتجهيزات المركز وأنشطته التوضيحية، ولا تُنشر صور الأطفال إلا بموافقة مسبقة ومكتوبة من الأهل.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick facility stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-[#E1E9E9] text-center shadow-xs">
                <span className="font-['Cairo'] font-black text-2xl text-[#0F3A42] block">300 م²</span>
                <span className="text-xs font-bold text-[#455B63]">مساحة المقر المجهز</span>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-[#E1E9E9] text-center shadow-xs">
                <span className="font-['Cairo'] font-black text-2xl text-[#B9862F] block">100%</span>
                <span className="text-xs font-bold text-[#455B63]">أمان وعناية فردية</span>
              </div>
            </div>

          </div>

        </div>

        {/* Milestone Timeline 2018 -> Today */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 border border-[#E1E9E9] shadow-sm mb-16">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold text-[#B9862F] font-['Cairo']">
              ماذا قدّم المركز حتى اليوم؟
            </span>
            <h3 className="font-['Cairo'] text-2xl font-black text-[#0F3A42] mt-1">
              مسيرة بدأت عام 2018 ولا تزال مستمرة
            </h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center relative">
            <div className="p-4 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9] flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#B9862F] text-white flex items-center justify-center font-bold text-xs mb-3 shadow-sm">
                2018
              </div>
              <b className="font-['Cairo'] text-xl text-[#B9862F]">2018</b>
              <span className="text-xs font-bold text-[#455B63] mt-1">انطلاق وتأسيس المركز</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9] flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#0F3A42] text-white flex items-center justify-center font-bold text-xs mb-3 shadow-sm">
                1
              </div>
              <b className="font-['Cairo'] text-2xl text-[#0F3A42]">+80</b>
              <span className="text-xs font-bold text-[#455B63] mt-1">حالة ضمن طيف التوحد</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9] flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#0F3A42] text-white flex items-center justify-center font-bold text-xs mb-3 shadow-sm">
                2
              </div>
              <b className="font-['Cairo'] text-2xl text-[#0F3A42]">+50</b>
              <span className="text-xs font-bold text-[#455B63] mt-1">حالة تأخر بالقدرات النمائية</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9] flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-[#0F3A42] text-white flex items-center justify-center font-bold text-xs mb-3 shadow-sm">
                3
              </div>
              <b className="font-['Cairo'] text-2xl text-[#0F3A42]">+40</b>
              <span className="text-xs font-bold text-[#455B63] mt-1">حالة صعوبات تربوية</span>
            </div>

            <div className="col-span-2 md:col-span-1 p-4 rounded-2xl bg-[#0F3A42] text-white flex flex-col items-center shadow-md">
              <div className="w-10 h-10 rounded-full bg-[#E7B96A] text-[#0F3A42] flex items-center justify-center font-bold text-xs mb-3 shadow-sm">
                اليوم
              </div>
              <b className="font-['Cairo'] text-xl text-[#E7B96A]">اليوم</b>
              <span className="text-xs font-bold text-[#EAF3F3] mt-1">صفوف تربوية وتأهيل مستمر</span>
            </div>
          </div>
        </div>

        {/* Facility Gallery */}
        <div>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
            <div className="text-right">
              <h3 className="font-['Cairo'] text-2xl font-bold text-[#0F3A42]">
                معرض مرافق وقاعات المركز
              </h3>
              <p className="text-xs sm:text-sm text-[#455B63]">
                تعرف على الغرف المتخصصة والبيئات الداعمة لكل خدمة علاجية
              </p>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 max-w-full">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'therapy', label: 'الجلسات الفردية' },
                { id: 'sensory', label: 'الركن الحسي' },
                { id: 'activities', label: 'الأنشطة والفنون' },
                { id: 'facilities', label: 'ملاعب وأمان' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategory(tab.id)}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold font-['Cairo'] transition-all whitespace-nowrap ${
                    activeCategory === tab.id
                      ? 'bg-[#0F3A42] text-white shadow-sm'
                      : 'bg-white text-[#455B63] hover:bg-gray-100 border border-[#E1E9E9]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGallery.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedImage(item)}
                className="group relative rounded-3xl overflow-hidden bg-white border border-[#E1E9E9] shadow-xs hover:shadow-xl transition-all duration-300 cursor-pointer"
              >
                <div className="aspect-[4/3] overflow-hidden bg-gray-100 relative">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                    <span className="text-white text-xs font-bold font-['Cairo'] flex items-center gap-1.5">
                      <Eye className="w-4 h-4 text-[#E7B96A]" /> تكبير واستعراض التفاصيل
                    </span>
                  </div>
                </div>

                <div className="p-4 text-right">
                  <span className="text-[10px] font-bold text-[#B9862F] bg-[#EAF3F3] px-2 py-0.5 rounded-full">
                    {item.tag}
                  </span>
                  <h4 className="font-['Cairo'] font-bold text-sm text-[#0F3A42] mt-1.5">
                    {item.title}
                  </h4>
                  <p className="text-xs text-[#455B63] mt-1 line-clamp-2">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div 
            className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-white/20 text-right animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-[16/10] bg-black">
              <img 
                src={selectedImage.imageUrl} 
                alt={selectedImage.title} 
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-3 left-3 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black"
                aria-label="إغلاق"
              >
                ✕
              </button>
            </div>
            <div className="p-6">
              <span className="text-xs font-bold text-[#B9862F] font-['Cairo'] bg-[#EAF3F3] px-2.5 py-1 rounded-full">
                {selectedImage.tag}
              </span>
              <h3 className="font-['Cairo'] text-xl font-bold text-[#0F3A42] mt-2">
                {selectedImage.title}
              </h3>
              <p className="text-sm text-[#455B63] mt-2 leading-relaxed">
                {selectedImage.desc}
              </p>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
