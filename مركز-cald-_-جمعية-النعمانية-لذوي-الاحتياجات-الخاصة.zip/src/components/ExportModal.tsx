import React, { useState } from 'react';
import { Download, Code2, Check, Copy, FileText, ChevronDown, ChevronUp, FolderArchive, Sparkles } from 'lucide-react';
import { CALD_PROJECT_FILES } from '../data/projectBundle';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<string>('src/App.tsx');
  const [copiedFile, setCopiedFile] = useState(false);
  const [activeTab, setActiveTab] = useState<'download' | 'browse'>('download');
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const fileNames = Object.keys(CALD_PROJECT_FILES);
  const filteredFiles = fileNames.filter(name => 
    name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Function to download all project files as a JSON / structured text bundle
  const handleDownloadFullJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(CALD_PROJECT_FILES, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "cald-website-complete-source.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Function to download a single file
  const handleDownloadSingleFile = (filename: string) => {
    const content = CALD_PROJECT_FILES[filename] || '';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", url);
    downloadAnchor.setAttribute("download", filename.split('/').pop() || 'file.txt');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    URL.revokeObjectURL(url);
  };

  const handleCopyCurrentFile = () => {
    const content = CALD_PROJECT_FILES[selectedFile] || '';
    navigator.clipboard.writeText(content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-gray-200 overflow-hidden text-right animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-[#0F3A42] p-5 sm:p-6 text-white flex items-center justify-between">
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm font-bold transition-colors"
            aria-label="إغلاق"
          >
            ✕
          </button>

          <div className="flex items-center gap-3">
            <div>
              <h3 className="font-['Cairo'] text-lg sm:text-xl font-bold text-white flex items-center gap-2 justify-end">
                <span>تنزيل واستعراض كود الموقع كاملاً</span>
                <FolderArchive className="w-5 h-5 text-[#E7B96A]" />
              </h3>
              <p className="text-xs text-[#A5C7C7] mt-0.5">
                كافة ملفات البرمجة والتصميم لموقع مركز CALD جاهزة بين يديك (27 ملفاً)
              </p>
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center border-b border-gray-200 bg-[#F4FAFA] px-4 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('download')}
            className={`px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-['Cairo'] font-bold flex items-center gap-2 border-t border-x transition-colors ${
              activeTab === 'download' 
                ? 'bg-white text-[#0F3A42] border-gray-200 -mb-px shadow-xs' 
                : 'text-[#455B63] border-transparent hover:bg-white/50'
            }`}
          >
            <Download className="w-4 h-4 text-[#B9862F]" />
            <span>تنزيل الحزمة والتعليمات</span>
          </button>

          <button
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-['Cairo'] font-bold flex items-center gap-2 border-t border-x transition-colors ${
              activeTab === 'browse' 
                ? 'bg-white text-[#0F3A42] border-gray-200 -mb-px shadow-xs' 
                : 'text-[#455B63] border-transparent hover:bg-white/50'
            }`}
          >
            <Code2 className="w-4 h-4 text-[#2E93A0]" />
            <span>تصفح ونسخ كود الملفات</span>
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {activeTab === 'download' ? (
            <div className="space-y-6">
              
              {/* Main Download Action Card */}
              <div className="bg-gradient-to-br from-[#EAF3F3] to-[#F4FAFA] p-6 rounded-2xl border border-[#2E93A0]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-right space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#B9862F]/15 text-[#B9862F] text-xs font-bold font-['Cairo'] mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>جاهز بنقرة واحدة</span>
                  </div>
                  <h4 className="font-['Cairo'] font-bold text-base sm:text-lg text-[#0F3A42]">
                    تنزيل الحزمة البرمجية الكاملة (27 ملفاً)
                  </h4>
                  <p className="text-xs text-[#455B63] max-w-md">
                    يحتوي الملف على كود كافة الصفحات والمكونات والبيانات ومعرض الصور ومكتبات التصميم مجمعة في ملف واحد.
                  </p>
                </div>

                <button
                  onClick={handleDownloadFullJSON}
                  className="w-full sm:w-auto bg-[#0F3A42] hover:bg-[#14535D] text-white px-6 py-3.5 rounded-xl font-['Cairo'] font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#0F3A42]/20 transition-all hover:scale-102 shrink-0"
                >
                  <Download className="w-5 h-5 text-[#E7B96A]" />
                  <span>تنزيل حزمة الملفات (JSON)</span>
                </button>
              </div>

              {/* Step by step deployment guide */}
              <div className="bg-white p-5 rounded-2xl border border-gray-200 text-right space-y-3">
                <h4 className="font-['Cairo'] font-bold text-sm text-[#0F3A42] flex items-center gap-2 justify-end">
                  <span>كيفية تشغيل ورفع الموقع على الإنترنت:</span>
                  <span className="w-2 h-2 rounded-full bg-[#6FAF52]" />
                </h4>
                
                <ol className="text-xs text-[#455B63] space-y-2 list-decimal list-inside leading-relaxed font-medium">
                  <li>
                    <strong>الخيار الأول (من واجهة المنصة مباشرة):</strong> يمكنك في أي وقت الضغط على خيار <span className="text-[#0F3A42] font-bold">Download as ZIP</span> أو <span className="text-[#0F3A42] font-bold">Export to GitHub</span> من القائمة العلوية.
                  </li>
                  <li>
                    <strong>الخيار الثاني (رفع مجاني سريع على Netlify أو Vercel):</strong> يمكنك ربط الكود بأي منصة استضافة سحابية بنقرة واحدة لتحصل على رابط دائم خاص بمركزكم مجاناً.
                  </li>
                  <li>
                    <strong>الخيار الثالث (تشغيل الموقع محلياً على جهازك):</strong>
                    <div className="mt-2 bg-[#0A2429] text-gray-200 p-3 rounded-xl font-mono text-[11px] text-left dir-ltr">
                      npm install<br />
                      npm run dev
                    </div>
                  </li>
                </ol>
              </div>

              {/* Quick file list breakdown */}
              <div className="space-y-2">
                <h5 className="font-['Cairo'] font-bold text-xs text-[#0F3A42] text-right">
                  قائمة الملفات المضمنة في المشروع ({fileNames.length} ملفاً):
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                  {fileNames.map(f => (
                    <div key={f} className="p-2.5 rounded-xl bg-gray-50 border border-gray-200 flex items-center justify-between text-gray-700">
                      <button 
                        onClick={() => handleDownloadSingleFile(f)}
                        className="text-[#2E93A0] hover:text-[#0F3A42] p-1 rounded-md hover:bg-gray-200"
                        title="تنزيل هذا الملف منفرداً"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono text-[11px] truncate">{f}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            /* Code Browser Tab */
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-full">
              
              {/* File list sidebar */}
              <div className="md:col-span-4 space-y-2 text-right">
                <input
                  type="text"
                  placeholder="ابحث عن ملف..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#2E93A0] text-right"
                />

                <div className="max-h-[350px] overflow-y-auto space-y-1 pr-1">
                  {filteredFiles.map(filename => (
                    <button
                      key={filename}
                      onClick={() => setSelectedFile(filename)}
                      className={`w-full text-right px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                        selectedFile === filename 
                          ? 'bg-[#0F3A42] text-white font-bold' 
                          : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5 opacity-70" />
                      <span className="truncate">{filename}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Code viewer column */}
              <div className="md:col-span-8 flex flex-col bg-[#0A2429] rounded-2xl overflow-hidden border border-gray-800">
                <div className="bg-[#07191C] px-4 py-2.5 flex items-center justify-between border-b border-gray-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyCurrentFile}
                      className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-['Cairo'] flex items-center gap-1.5 transition-colors"
                    >
                      {copiedFile ? <Check className="w-3.5 h-3.5 text-[#6FAF52]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedFile ? 'تم النسخ!' : 'نسخ الكود'}</span>
                    </button>
                    <button
                      onClick={() => handleDownloadSingleFile(selectedFile)}
                      className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-['Cairo'] flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>تنزيل</span>
                    </button>
                  </div>
                  <span className="text-xs font-mono text-[#E7B96A] truncate max-w-[200px]">
                    {selectedFile}
                  </span>
                </div>

                <pre className="p-4 text-xs font-mono text-gray-200 overflow-x-auto overflow-y-auto max-h-[340px] text-left dir-ltr leading-relaxed">
                  <code>{CALD_PROJECT_FILES[selectedFile] || '// لا يوجد محتوى'}</code>
                </pre>
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gray-200 hover:bg-gray-300 text-gray-800 text-xs font-bold font-['Cairo']"
          >
            إغلاق
          </button>
          
          <div className="text-[11px] text-[#455B63] font-['Cairo']">
            جميع حقوق البرمجة والتصميم محفوظة لـ <strong>مركز CALD | جمعية النعمانية</strong>
          </div>
        </div>

      </div>
    </div>
  );
};
