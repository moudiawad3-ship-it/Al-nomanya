import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';
import { FAQ_DATA } from '../data/contentData';

export const FAQSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('f1');

  const toggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <HelpCircle className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>الأسئلة الشائعة</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            إجابات واضحة لاستفساراتكم
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-sm sm:text-base text-[#455B63] font-medium">
            كل ما يهم الأهل والداعمين والمهتمين حول خدمات المركز وبرامج الكفالة والتسجيل.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {FAQ_DATA.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div 
                key={item.id}
                className={`rounded-2xl border transition-all duration-200 text-right overflow-hidden ${
                  isOpen 
                    ? 'bg-[#F4FAFA] border-[#2E93A0]/40 shadow-sm' 
                    : 'bg-white border-[#E1E9E9] hover:border-gray-300'
                }`}
              >
                <button
                  onClick={() => toggle(item.id)}
                  className="w-full p-5 sm:p-6 flex items-center justify-between gap-4 font-['Cairo'] font-bold text-base text-[#0F3A42] text-right focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className="flex-1">{item.question}</span>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                    isOpen ? 'bg-[#0F3A42] text-white' : 'bg-[#EAF3F3] text-[#0F3A42]'
                  }`}>
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base text-[#455B63] leading-relaxed border-t border-[#E1E9E9]/60 font-medium">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
