import React, { useState } from 'react';
import { 
  ClipboardCheck, 
  Brain, 
  MessageSquareText, 
  Activity, 
  Users, 
  Smile, 
  Zap, 
  Check, 
  ArrowLeft,
  Sparkles,
  Info,
  Calendar
} from 'lucide-react';
import { SERVICES_DATA } from '../data/contentData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onOpenAssessment: () => void;
  onOpenDonate: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ 
  onOpenAssessment,
  onOpenDonate
}) => {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ClipboardCheck':
        return <ClipboardCheck className="w-6 h-6" />;
      case 'Brain':
        return <Brain className="w-6 h-6" />;
      case 'MessageSquareText':
        return <MessageSquareText className="w-6 h-6" />;
      case 'Activity':
        return <Activity className="w-6 h-6" />;
      case 'Users':
        return <Users className="w-6 h-6" />;
      case 'Smile':
        return <Smile className="w-6 h-6" />;
      case 'Zap':
        return <Zap className="w-6 h-6" />;
      default:
        return <Sparkles className="w-6 h-6" />;
    }
  };

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>برامجنا العلاجية والتأهيلية</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            سبع خدمات متكاملة حول الطفل وعائلته
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            منظومة علاجية وتربوية متكاملة تقدمها كوادر مؤهلة وفق أحدث المعايير العلمية العالمية.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES_DATA.map((service) => (
            <div
              key={service.id}
              className={`rounded-3xl p-7 border transition-all duration-300 flex flex-col justify-between group ${
                service.isWide 
                  ? 'md:col-span-2 lg:col-span-3 bg-gradient-to-br from-[#0F3A42] via-[#14535D] to-[#1C6670] text-white border-transparent shadow-xl' 
                  : 'bg-[#FCFDFC] hover:bg-white text-[#17282B] border-[#E1E9E9] hover:border-[#2E93A0]/40 shadow-xs hover:shadow-xl hover:-translate-y-1'
              }`}
            >
              <div>
                {/* Header Icon & Tag */}
                <div className="flex items-center justify-between mb-5">
                  <div 
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 ${
                      service.isWide 
                        ? 'bg-white/15 text-[#E7B96A]' 
                        : 'bg-[#EAF3F3] text-[#0F3A42]'
                    }`}
                  >
                    {getIcon(service.iconName)}
                  </div>
                  
                  <span className={`text-xs font-bold font-['Cairo'] px-3 py-1 rounded-full ${
                    service.isWide 
                      ? 'bg-white/10 text-white border border-white/20' 
                      : 'bg-[#F4FAFA] text-[#455B63] border border-[#E1E9E9]'
                  }`}>
                    خدمة متخصصة
                  </span>
                </div>

                <h3 className={`font-['Cairo'] text-xl font-bold mb-3 ${
                  service.isWide ? 'text-white' : 'text-[#0F3A42]'
                }`}>
                  {service.title}
                </h3>

                <p className={`text-sm leading-relaxed mb-6 ${
                  service.isWide ? 'text-[#DDEFEF]' : 'text-[#455B63]'
                }`}>
                  {service.shortDesc}
                </p>

                {/* Benefits Pill List */}
                <div className="space-y-2 mb-6">
                  {service.benefits.map((benefit, bIdx) => (
                    <div key={bIdx} className="flex items-center gap-2 text-xs font-semibold">
                      <div className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 ${
                        service.isWide ? 'bg-[#E7B96A] text-[#0F3A42]' : 'bg-[#2E93A0]/15 text-[#2E93A0]'
                      }`}>
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      </div>
                      <span className={service.isWide ? 'text-white/90' : 'text-[#17282B]'}>
                        {benefit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className={`pt-4 border-t flex items-center justify-between ${
                service.isWide ? 'border-white/15' : 'border-gray-100'
              }`}>
                <button
                  onClick={() => setSelectedService(service)}
                  className={`text-xs font-bold font-['Cairo'] inline-flex items-center gap-1.5 transition-colors ${
                    service.isWide 
                      ? 'text-[#E7B96A] hover:text-white' 
                      : 'text-[#0F3A42] hover:text-[#B9862F]'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>تفاصيل المنهجية العلاجية</span>
                </button>

                <button
                  onClick={onOpenAssessment}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold font-['Cairo'] transition-all ${
                    service.isWide 
                      ? 'bg-[#B9862F] hover:bg-[#9E7024] text-white shadow-sm' 
                      : 'bg-[#EAF3F3] hover:bg-[#0F3A42] text-[#0F3A42] hover:text-white'
                  }`}
                >
                  طلب الخدمة
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-[#E1E9E9] text-right animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] text-[#0F3A42] flex items-center justify-center">
                  {getIcon(selectedService.iconName)}
                </div>
                <div>
                  <h3 className="font-['Cairo'] text-xl font-bold text-[#0F3A42]">
                    {selectedService.title}
                  </h3>
                  <span className="text-xs text-[#B9862F] font-bold font-['Cairo']">
                    مركز CALD — جمعية النعمانية
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="text-gray-400 hover:text-gray-700 p-2 rounded-xl hover:bg-gray-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-sm text-[#455B63] leading-relaxed">
              <p className="font-medium text-[#17282B]">
                {selectedService.fullDesc}
              </p>

              <div>
                <h4 className="font-['Cairo'] font-bold text-sm text-[#0F3A42] mb-2.5">
                  أبرز المحاور والأهداف المحققة:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedService.benefits.map((b, i) => (
                    <div key={i} className="flex items-center gap-2 bg-[#F4FAFA] p-2.5 rounded-xl text-xs font-semibold text-[#17282B] border border-[#E1E9E9]">
                      <Check className="w-3.5 h-3.5 text-[#6FAF52] shrink-0 stroke-[3]" />
                      <span>{b}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedService(null)}
                className="px-4 py-2 rounded-full text-xs font-bold text-gray-600 hover:bg-gray-100 font-['Cairo']"
              >
                إغلاق
              </button>
              <button
                onClick={() => {
                  setSelectedService(null);
                  onOpenAssessment();
                }}
                className="px-6 py-2.5 rounded-full text-xs sm:text-sm font-bold bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] flex items-center gap-1.5 shadow-md"
              >
                <Calendar className="w-3.5 h-3.5 text-[#E7B96A]" />
                <span>حجز استشارة لهذه الخدمة</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
