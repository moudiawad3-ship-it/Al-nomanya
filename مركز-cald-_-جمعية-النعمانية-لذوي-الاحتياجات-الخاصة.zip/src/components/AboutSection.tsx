import React from 'react';
import { 
  Building2, 
  MapPin, 
  Target, 
  Heart, 
  Calendar, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  Car, 
  MapPinOff, 
  HeartHandshake,
  Compass
} from 'lucide-react';
import { WHY_IT_MATTERS } from '../data/contentData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <Compass className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>رسالتنا وهويتنا</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            مركز متخصص وُلد من حاجة حقيقية في عكار والشمال
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            نعمل في جمعية النعمانية منذ عام 2018 لتمكين الأطفال ذوي الاحتياجات الخاصة من حقوقهم الكاملة في التعلم والعلاج والكرامة الإنسانية.
          </p>
        </div>

        {/* Story & Facility Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          
          {/* Left Column: Visual Highlights Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-[#0F3A42] via-[#14535D] to-[#1C6670] p-8 text-white">
              
              {/* Subtle background graphics */}
              <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/5 pointer-events-none" />
              <div className="absolute -bottom-10 -right-10 w-60 h-60 rounded-full bg-[#B9862F]/20 pointer-events-none" />

              <div className="relative z-10 space-y-6">
                <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-[#E7B96A]">
                  <Building2 className="w-7 h-7" />
                </div>

                <h3 className="font-['Cairo'] text-2xl font-bold leading-snug">
                  مرافق حديثة مخصصة لسلامة وتطور الطفل
                </h3>

                <p className="text-sm text-[#EAF3F3] leading-relaxed">
                  صُمم المقر الرئيسي بمساحة تبلغ نحو <strong className="text-white text-base">300 م²</strong> ليحتضن صفوفاً تربوية مجهزة، وغرف جلسات فردية، وركناً حسياً متكاملاً، وملاعب داخلية آمنة.
                </p>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2.5 rounded-xl border border-white/15">
                    <CheckCircle2 className="w-5 h-5 text-[#E7B96A] shrink-0" />
                    <span className="text-xs sm:text-sm font-semibold">صفوف تربوية مكيّفة ومجهزة بالوسائل البصرية</span>
                  </div>
                  <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2.5 rounded-xl border border-white/15">
                    <CheckCircle2 className="w-5 h-5 text-[#E7B96A] shrink-0" />
                    <span className="text-xs sm:text-sm font-semibold">غرف جلسات فردية عازلة للمشتتات</span>
                  </div>
                  <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2.5 rounded-xl border border-white/15">
                    <CheckCircle2 className="w-5 h-5 text-[#E7B96A] shrink-0" />
                    <span className="text-xs sm:text-sm font-semibold">فرع إضافي في المنية لتغطية محيط طرابلس والسهل</span>
                  </div>
                </div>

                <div className="bg-[#B9862F] text-white p-4 rounded-2xl text-center font-['Cairo'] font-bold text-sm shadow-md mt-6">
                  🎯 هدفنا: توفير فرصة أقرب وأفضل للأطفال في عكار والشمال
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Detailed Context & Narrative */}
          <div className="lg:col-span-7 space-y-6 text-right">
            
            <div className="border-r-4 border-[#1C6670] pr-4">
              <h3 className="font-['Cairo'] text-2xl font-bold text-[#0F3A42]">
                مسيرة متواصلة في رعاية أصحاب الهمم
              </h3>
              <p className="text-xs font-semibold text-[#B9862F] mt-1 font-['Cairo']">
                الريادة التخصصية في محافظة عكار والشمال منذ 2018
              </p>
            </div>

            <p className="text-base text-[#455B63] leading-relaxed">
              مركز CALD هو مركز متخصص في عكار والشمال، يعمل منذ عام 2018، ويقدّم خدمات تربوية وعلاجية لأطفال التوحد وصعوبات التعلم، إلى جانب الدعم النفسي والإرشاد الأسري والتوعية المجتمعية.
            </p>

            <p className="text-base text-[#455B63] leading-relaxed">
              انطلق المركز استجابةً للمعاناة الكبيرة التي كان يواجهها أهالي المنطقة، حيث كانت خيارات العلاج المتخصص نادرة وتتطلب السفر لمسافات طويلة وبتكاليف تفوق طاقة العائلات. اليوم، نجمع تحت سقف واحد فريقاً متكاملاً من أخصائيي النطق، العلاج الإشغالي، التربية المختصة، والدعم النفسي.
            </p>

            {/* Quick Feature Chips */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-4">
              <div className="flex items-start gap-3 bg-[#F4FAFA] p-3.5 rounded-2xl border border-[#E1E9E9]">
                <div className="w-8 h-8 rounded-xl bg-[#EAF3F3] text-[#134A54] flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-['Cairo'] font-bold text-xs text-[#0F3A42]">بيئة آمنة وصديقة للحواس</h4>
                  <p className="text-[11px] text-[#455B63] mt-0.5">معايير أمان عالية تراعي الحساسيات الحسية للأطفال.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-[#F4FAFA] p-3.5 rounded-2xl border border-[#E1E9E9]">
                <div className="w-8 h-8 rounded-xl bg-[#EAF3F3] text-[#B9862F] flex items-center justify-center shrink-0">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-['Cairo'] font-bold text-xs text-[#0F3A42]">شراكة لصيقة مع الأسرة</h4>
                  <p className="text-[11px] text-[#455B63] mt-0.5">إشراك الوالدين في كل مرحلة لضمان استمرار الأثر في المنزل.</p>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Why this center matters section */}
        <div className="pt-10 border-t border-[#E1E9E9]">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold text-[#B9862F] font-['Cairo'] uppercase tracking-wider">
              لماذا هذا المركز مهم؟
            </span>
            <h3 className="font-['Cairo'] text-2xl font-extrabold text-[#0F3A42] mt-1">
              فجوة حقيقية نعمل كل يوم على سدّها
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {WHY_IT_MATTERS.map((item, idx) => (
              <div 
                key={item.id}
                className="bg-[#FCFDFC] hover:bg-white rounded-2xl p-6 border border-[#E1E9E9] hover:border-[#2E93A0]/40 shadow-xs hover:shadow-lg hover:-translate-y-1 transition-all text-center flex flex-col items-center"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#EAF3F3] flex items-center justify-center mb-4 text-[#134A54]">
                  {idx === 0 && <MapPinOff className="w-7 h-7 text-[#134A54]" />}
                  {idx === 1 && <Car className="w-7 h-7 text-[#B9862F]" />}
                  {idx === 2 && <Clock className="w-7 h-7 text-[#2E93A0]" />}
                  {idx === 3 && <HeartHandshake className="w-7 h-7 text-[#6FAF52]" />}
                </div>
                <h4 className="font-['Cairo'] font-bold text-base text-[#0F3A42] mb-2">
                  {item.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#455B63] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
