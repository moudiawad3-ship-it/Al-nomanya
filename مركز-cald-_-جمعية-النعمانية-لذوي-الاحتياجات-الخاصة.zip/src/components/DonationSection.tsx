import React, { useState } from 'react';
import { 
  Heart, 
  Sparkles, 
  Award, 
  CalendarCheck, 
  Layers, 
  HeartHandshake, 
  Quote, 
  FileText, 
  Receipt, 
  Target, 
  Lock,
  Building,
  Zap,
  BookOpen,
  Users2,
  CheckCircle2,
  ArrowLeft
} from 'lucide-react';
import { TRUST_AND_TRANSPARENCY } from '../data/contentData';

interface DonationSectionProps {
  onOpenDonateModal: (presetTitle?: string) => void;
  onOpenVolunteer: () => void;
}

export const DonationSection: React.FC<DonationSectionProps> = ({ 
  onOpenDonateModal, 
  onOpenVolunteer 
}) => {
  const helpCards = [
    { id: 'h1', title: 'المساهمة في تشغيل المركز', icon: 'Building', desc: 'دعم المصاريف التشغيلية والتدفئة والمستلزمات اليومية.' },
    { id: 'h2', title: 'تجهيز غرفة علاج', icon: 'Layers', desc: 'شراء المعدات الطبية والحسية لغرف التأهيل.' },
    { id: 'h3', title: 'دعم جلسات علاجية لطفل', icon: 'Sparkles', desc: 'كفالة جلسات نطق أو دعم نفسي أو علاج إشغالي.' },
    { id: 'h4', title: 'كفالة طفل لمدة سنة', icon: 'Award', desc: 'رعاية تأهيلية وتربوية متكاملة لعام دراسي كامل.' },
    { id: 'h5', title: 'المساهمة في دعم المصعد', icon: 'Zap', desc: 'تسهيل وصول الأطفال ذوي الإعاقة الحركية للطوابق.' },
    { id: 'h6', title: 'دعم برنامج توعية للأهل', icon: 'Users2', desc: 'تمويل ورش العمل والإرشاد الأسري التخصصي.' },
    { id: 'h7', title: 'دعم برنامج التعليم التعويضي', icon: 'BookOpen', desc: 'استلحاق دراسي للأطفال المتأخرين أكاديمياً.' },
    { id: 'h8', title: 'التطوّع مع فريقنا', icon: 'HeartHandshake', isVolunteer: true, desc: 'مشاركة خبراتك التربوية أو الطبية أو التنظيمية.' },
  ];

  return (
    <section id="get-involved" className="py-20 bg-[#F4FAFA] border-y border-[#E1E9E9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <Heart className="w-3.5 h-3.5 text-[#B9862F] fill-current" />
            <span>المشاركة والعطاء</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            كيف يمكنك أن تساعد؟
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            يمكنك اختيار بند محدد أو المساهمة بمبلغ مفتوح — كل مساهمة، مهما كان حجمها، تصنع فرقاً حقيقياً في حياة طفل.
          </p>
        </div>

        {/* 8 Help Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {helpCards.map((card) => (
            <div
              key={card.id}
              onClick={() => {
                if (card.isVolunteer) {
                  onOpenVolunteer();
                } else {
                  onOpenDonateModal(card.title);
                }
              }}
              className="bg-white rounded-3xl p-6 border border-[#E1E9E9] shadow-xs hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between cursor-pointer group text-center"
            >
              <div>
                <div className="w-14 h-14 rounded-2xl bg-[#EAF3F3] text-[#134A54] group-hover:bg-[#0F3A42] group-hover:text-white flex items-center justify-center mx-auto mb-4 transition-colors shadow-xs">
                  {card.id === 'h1' && <Building className="w-7 h-7" />}
                  {card.id === 'h2' && <Layers className="w-7 h-7" />}
                  {card.id === 'h3' && <Sparkles className="w-7 h-7" />}
                  {card.id === 'h4' && <Award className="w-7 h-7" />}
                  {card.id === 'h5' && <Zap className="w-7 h-7" />}
                  {card.id === 'h6' && <Users2 className="w-7 h-7" />}
                  {card.id === 'h7' && <BookOpen className="w-7 h-7" />}
                  {card.id === 'h8' && <HeartHandshake className="w-7 h-7 text-[#B9862F]" />}
                </div>

                <h4 className="font-['Cairo'] font-bold text-base text-[#0F3A42] mb-2 group-hover:text-[#1C6670] transition-colors">
                  {card.title}
                </h4>

                <p className="text-xs text-[#455B63] leading-relaxed">
                  {card.desc}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-gray-100 flex items-center justify-center text-xs font-bold text-[#B9862F] group-hover:text-[#0F3A42]">
                <span>{card.isVolunteer ? 'تقديم طلب تطوع ←' : 'ساهم في هذا البند ←'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Golden Quote Banner */}
        <div className="rounded-3xl bg-[#0F3A42] text-white p-8 sm:p-12 shadow-xl mb-20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#2E93A0]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 text-center md:text-right justify-between">
            <div className="flex items-center gap-5">
              <div className="w-16 h-16 rounded-3xl bg-[#B9862F] text-white flex items-center justify-center shrink-0 shadow-lg">
                <Quote className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-['Cairo'] text-2xl sm:text-3xl font-black text-white leading-snug">
                  كل مساهمة تفتح فرصة حقيقية لطفل وعائلته
                </h3>
                <p className="text-sm text-[#DDEFEF] mt-1 font-medium">
                  معاً نكسر العزلة ونبني مستقبلاً مفعماً بالأمل والاستقلالية في عكار والشمال.
                </p>
              </div>
            </div>

            <button
              onClick={() => onOpenDonateModal('كفالة شاملة')}
              className="shrink-0 bg-[#B9862F] hover:bg-[#E7B96A] hover:text-[#0F3A42] text-white font-['Cairo'] font-bold text-sm sm:text-base px-8 py-3.5 rounded-full shadow-lg transition-all"
            >
              كفالة طفل الآن
            </button>
          </div>
        </div>

        {/* Expected Impact (5 pillars) */}
        <div className="mb-20">
          <div className="text-center max-w-xl mx-auto mb-12">
            <span className="text-xs font-bold text-[#B9862F] font-['Cairo']">
              عطاء يغير الواقع
            </span>
            <h3 className="font-['Cairo'] text-2xl font-black text-[#0F3A42] mt-1">
              ما الأثر المتوقّع من دعمك؟
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { title: 'تمكين الأطفال من الوصول إلى خدمات منظّمة', icon: 'Target', desc: 'جلسات مستمرة دون انقطاع بسبب العجز المالي.' },
              { title: 'تعزيز التواصل والانتباه والمهارات اليومية', icon: 'Sparkles', desc: 'نقلات نوعية في النطق والاعتماد على النفس.' },
              { title: 'تخفيف العبء المالي عن الأهالي', icon: 'Heart', desc: 'توفير مئات الدولارات من تكاليف السفر والجلسات.' },
              { title: 'خلق بيئة أكثر أماناً وملاءمة للتعلّم', icon: 'Layers', desc: 'تجهيزات ومصاعد وأرضيات مبطنة تحفظ سلامتهم.' },
              { title: 'توسيع الوصول للدعم داخل عكار والشمال', icon: 'Building', desc: 'فتح فروع وقاعات تستوعب أعداداً إضافية.' },
            ].map((impact, idx) => (
              <div key={idx} className="bg-white p-5 rounded-2xl border border-[#E1E9E9] text-center shadow-xs">
                <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] text-[#0F3A42] flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-6 h-6 text-[#6FAF52]" />
                </div>
                <h4 className="font-['Cairo'] font-bold text-xs sm:text-sm text-[#0F3A42] mb-1.5 leading-snug">
                  {impact.title}
                </h4>
                <p className="text-[11px] text-[#455B63] leading-relaxed">
                  {impact.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Transparency & Trust Section */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 border border-[#E1E9E9] shadow-sm">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold text-[#B9862F] font-['Cairo']">
              قيمنا المؤسسية
            </span>
            <h3 className="font-['Cairo'] text-2xl font-black text-[#0F3A42] mt-1">
              الشفافية والأمانة والثقة
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TRUST_AND_TRANSPARENCY.map((item) => (
              <div key={item.id} className="flex items-start gap-4 p-4 rounded-2xl bg-[#F4FAFA] border border-[#E1E9E9]">
                <div className="w-10 h-10 rounded-xl bg-[#EAF3F3] text-[#134A54] flex items-center justify-center shrink-0">
                  {item.id === 't1' && <FileText className="w-5 h-5" />}
                  {item.id === 't2' && <Receipt className="w-5 h-5" />}
                  {item.id === 't3' && <Target className="w-5 h-5" />}
                  {item.id === 't4' && <Lock className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="font-['Cairo'] font-bold text-sm text-[#0F3A42] mb-1">
                    {item.title}
                  </h4>
                  <p className="text-xs text-[#455B63] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
