import React, { useState } from 'react';
import { 
  X, 
  HeartHandshake, 
  Check, 
  Send, 
  Award, 
  GraduationCap, 
  Clock, 
  Phone
} from 'lucide-react';

interface VolunteerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VolunteerModal: React.FC<VolunteerModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [specialty, setSpecialty] = useState('علاج نطق ولغة');
  const [experience, setExperience] = useState('');
  const [preferredBranch, setPreferredBranch] = useState('حلبا — عكار');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const resetForm = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E1E9E9] text-right animate-in zoom-in-95 duration-200 my-8">
        
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] text-[#0F3A42] flex items-center justify-center">
              <HeartHandshake className="w-6 h-6 text-[#2E93A0]" />
            </div>
            <div>
              <h3 className="font-['Cairo'] text-xl font-bold text-[#0F3A42]">
                الانضمام لفريق المتطوعين
              </h3>
              <p className="text-xs text-[#455B63]">
                مركز CALD — جمعية النعمانية لذوي الاحتياجات الخاصة
              </p>
            </div>
          </div>
          <button
            onClick={resetForm}
            className="text-gray-400 hover:text-gray-700 p-2 rounded-xl hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#6FAF52]/20 text-[#6FAF52] flex items-center justify-center mx-auto mb-2 animate-bounce">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <h4 className="font-['Cairo'] text-2xl font-black text-[#0F3A42]">
              أهلاً بك في عائلة CALD، {name}!
            </h4>
            <p className="text-sm text-[#455B63] leading-relaxed max-w-sm mx-auto">
              سعداء جداً برغبتك في مشاركة خبرتك في مجال <strong>{specialty}</strong>. ستتواصل معك إدارة المركز عبر الرقم <strong>{phone}</strong> لتنسيق موعد اللقاء والتعريف ببرامجنا.
            </p>
            <button
              onClick={resetForm}
              className="w-full py-3 rounded-full bg-[#0F3A42] text-white font-['Cairo'] font-bold text-sm hover:bg-[#14535D] transition-colors mt-4"
            >
              تم
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <p className="text-xs text-[#455B63] leading-relaxed">
              نرحب بالكوادر المتخصصة والطلاب الجامعيين والمهتمين في مجالات التربية المختصة، علاج النطق، الدعم النفسي، الفنون، والتنظيم المجتمعي.
            </p>

            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                الاسم الثلاثي:
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="الاسم الكامل"
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                رقم الهاتف / واتساب:
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="مثال: 76801069"
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs text-left focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                المجال أو التخصص:
              </label>
              <select
                value={specialty}
                onChange={(e) => setSpecialty(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs font-semibold text-[#17282B] focus:ring-2 focus:ring-[#2E93A0] focus:outline-none bg-white font-['Cairo']"
              >
                <option value="علاج نطق ولغة">علاج نطق ولغة (Speech Therapy)</option>
                <option value="تربية مختصة وصعوبات تعلم">تربية مختصة وصعوبات تعلم (Special Ed)</option>
                <option value="علاج نفسي وإرشاد أسري">علاج نفسي وإرشاد أسري (Psychology)</option>
                <option value="علاج إشغالي وتكامل حسي">علاج إشغالي وتكامل حسي (OT)</option>
                <option value="علاج فيزيائي وتأهيل">علاج فيزيائي وتأهيل حركي (PT)</option>
                <option value="فنون وأنشطة وترفيه">فنون ورسم وأنشطة ترفيهية</option>
                <option value="إعلام وتصوير وتنسيق">إعلام وتصوير وتنسيق فعاليات</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  الفرع الأقرب لك:
                </label>
                <select
                  value={preferredBranch}
                  onChange={(e) => setPreferredBranch(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs font-['Cairo'] bg-white"
                >
                  <option value="حلبا — عكار">فرع حلبا — عكار (المقر الرئيسي)</option>
                  <option value="المنية">فرع المنية</option>
                </select>
              </div>

              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  سنوات الخبرة أو الدراسة:
                </label>
                <input
                  type="text"
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  placeholder="مثال: سنتان / طالب سنة ثالثة"
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0]"
                />
              </div>
            </div>

            <div className="pt-3 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-gray-800 font-['Cairo']"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-xs sm:text-sm shadow-md flex items-center gap-1.5"
              >
                <Send className="w-4 h-4 text-[#E7B96A]" />
                <span>إرسال طلب التطوع</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
