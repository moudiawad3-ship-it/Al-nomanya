import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  Heart, 
  PhoneCall, 
  Sparkles, 
  ChevronLeft,
  Calendar,
  Building2,
  Users
} from 'lucide-react';
import { CALD_LOGO_BASE64 } from '../data/contentData';

interface NavbarProps {
  onOpenDonate: () => void;
  onOpenAssessment: () => void;
  onOpenVolunteer: () => void;
  onOpenExport?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenDonate, 
  onOpenAssessment,
  onOpenVolunteer,
  onOpenExport
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'من نحن', href: '#about' },
    { name: 'من نخدم', href: '#who-we-serve' },
    { name: 'خدماتنا', href: '#services' },
    { name: 'جولة ومرافق', href: '#tour-gallery' },
    { name: 'احتياجات المركز', href: '#needs' },
    { name: 'كيف تساهم', href: '#get-involved' },
    { name: 'الفروع والتواصل', href: '#contact' },
  ];

  return (
    <header 
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-md border-b border-[#E1E9E9] py-2.5' 
          : 'bg-[#FCFDFC]/90 backdrop-blur-sm border-b border-[#E1E9E9]/60 py-3.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo & Brand Identity */}
          <a href="#" className="flex items-center gap-3.5 group text-right">
            <div className="relative">
              <img 
                src={CALD_LOGO_BASE64} 
                alt="شعار مركز CALD وجمعية النعمانية" 
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover shadow-md border-2 border-[#1C6670]/20 group-hover:scale-105 transition-transform"
              />
              <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-[#6FAF52] border-2 border-white rounded-full" title="مفتوح لاستقبال الأطفال" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Cairo'] font-extrabold text-lg sm:text-xl text-[#0F3A42] tracking-tight group-hover:text-[#1C6670] transition-colors">
                  مركز CALD
                </span>
                <span className="text-[11px] font-bold bg-[#EAF3F3] text-[#134A54] px-2 py-0.5 rounded-full border border-[#2E93A0]/30 hidden sm:inline-block">
                  جمعية النعمانية
                </span>
              </div>
              <p className="text-xs text-[#455B63] font-medium mt-0.5">
                التوحد وصعوبات التعلم — عكار والشمال
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-sm font-bold font-['Cairo'] text-[#17282B]">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-[#455B63] hover:text-[#1C6670] transition-colors py-1 relative group"
              >
                {link.name}
                <span className="absolute bottom-0 right-0 w-0 h-0.5 bg-[#B9862F] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={onOpenAssessment}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-bold font-['Cairo'] border border-[#0F3A42] text-[#0F3A42] hover:bg-[#0F3A42] hover:text-white transition-all shadow-sm"
              title="احجز موعد تقييم وتشخيص لطفلك"
            >
              <Calendar className="w-3.5 h-3.5 text-[#B9862F]" />
              <span>تقييم أولي</span>
            </button>

            <button
              onClick={onOpenDonate}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs sm:text-sm font-bold font-['Cairo'] bg-[#0F3A42] hover:bg-[#B9862F] text-white transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5"
            >
              <Heart className="w-4 h-4 text-[#E7B96A] fill-current" />
              <span>ساهم معنا</span>
            </button>
          </div>

          {/* Mobile menu trigger */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onOpenDonate}
              className="p-2 rounded-full bg-[#0F3A42] text-white text-xs font-bold sm:hidden flex items-center justify-center"
              aria-label="ساهم الآن"
            >
              <Heart className="w-4 h-4 text-[#E7B96A] fill-current" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-[#0F3A42] hover:bg-gray-100 transition-colors focus:outline-none"
              aria-label="فتح القائمة الرئيسية"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-[#E1E9E9] shadow-xl px-6 py-5 animate-in slide-in-from-top-3 duration-200">
          <div className="space-y-3 font-['Cairo'] font-bold text-base text-[#17282B]">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between py-2 border-b border-gray-100 text-[#455B63] hover:text-[#1C6670]"
              >
                <span>{link.name}</span>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </a>
            ))}
          </div>

          <div className="mt-5 pt-4 border-t border-gray-100 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAssessment();
              }}
              className="w-full py-2.5 rounded-xl font-bold font-['Cairo'] text-sm border-2 border-[#0F3A42] text-[#0F3A42] flex items-center justify-center gap-2 hover:bg-[#EAF3F3]"
            >
              <Calendar className="w-4 h-4 text-[#B9862F]" />
              حجز موعد تقييم أولي للطفل
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDonate();
              }}
              className="w-full py-3 rounded-xl font-bold font-['Cairo'] text-sm bg-[#0F3A42] text-white flex items-center justify-center gap-2 shadow-md hover:bg-[#B9862F]"
            >
              <Heart className="w-4 h-4 text-[#E7B96A] fill-current" />
              ساهم في كفالة طفل أو تجهيز المركز
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenVolunteer();
              }}
              className="w-full py-2 rounded-xl font-bold font-['Cairo'] text-xs text-[#455B63] hover:text-[#0F3A42] flex items-center justify-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5 text-[#2E93A0]" />
              انضم لفريق المتطوعين والأخصائيين
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
