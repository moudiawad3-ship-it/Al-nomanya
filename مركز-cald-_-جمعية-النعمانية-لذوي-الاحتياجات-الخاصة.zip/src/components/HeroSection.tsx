import React from 'react';
import { 
  ArrowLeft, 
  Heart, 
  Sparkles, 
  ShieldCheck, 
  Calendar, 
  MapPin, 
  CheckCircle2,
  Users,
  Award
} from 'lucide-react';
import { CALD_LOGO_BASE64, STATS_DATA } from '../data/contentData';

interface HeroSectionProps {
  onOpenDonate: () => void;
  onOpenAssessment: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ 
  onOpenDonate, 
  onOpenAssessment 
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 bg-gradient-to-b from-[#EAF3F3]/60 via-[#FCFDFC] to-white">
      {/* Background Decorative Blobs */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#2E93A0]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#E0A83E]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Main Hero Text Column */}
          <div className="lg:col-span-7 text-right">
            
            {/* Institution Badge */}
            <div className="inline-flex items-center gap-2 bg-[#EAF3F3] text-[#0F3A42] border border-[#2E93A0]/30 px-4 py-1.5 rounded-full text-xs sm:text-sm font-bold font-['Cairo'] mb-5 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-[#6FAF52] animate-pulse" />
              <span>مركز CALD — جمعية النعمانية</span>
              <span className="text-[#B9862F]">· عكار والشمال · منذ 2018</span>
            </div>

            {/* Headline */}
            <h1 className="font-['Cairo'] text-3xl sm:text-4xl md:text-5xl lg:text-[46px] font-black text-[#0F3A42] leading-[1.3] sm:leading-[1.35] tracking-tight">
              فرصة تعلّم حقيقية لكل طفل،{' '}
              <span className="text-[#B9862F] relative inline-block">
                خطوة بخطوة
                <svg className="absolute -bottom-2 right-0 w-full h-3 text-[#E7B96A]/60" viewBox="0 0 100 20" preserveAspectRatio="none">
                  <path d="M0,10 Q50,20 100,10" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              </span>{' '}
              نحو الاستقلالية
            </h1>

            {/* Lead description */}
            <p className="mt-5 text-base sm:text-lg text-[#455B63] leading-relaxed max-w-2xl font-medium">
              نرافق أطفال طيف التوحد، ومتلازمة داون، وصعوبات التعلم والانتباه في عكار والشمال، بخدمات تربوية وعلاجية ونفسية متكاملة — ونمشي إلى جانب عائلاتهم في كل خطوة من الرحلة.
            </p>

            {/* Four Pillars Color Dash */}
            <div className="flex items-center gap-2 my-6">
              <span className="w-8 h-1.5 rounded-full bg-[#6FAF52]" title="النمو والتربية" />
              <span className="w-8 h-1.5 rounded-full bg-[#2E93A0]" title="التواصل والنطق" />
              <span className="w-8 h-1.5 rounded-full bg-[#E0A83E]" title="التكامل الحسي" />
              <span className="w-8 h-1.5 rounded-full bg-[#D2665A]" title="التأهيل الحركي" />
              <span className="text-xs text-[#455B63] font-semibold mr-2">منهجية علاجية متعددة الأبعاد</span>
            </div>

            {/* Call to Actions */}
            <div className="flex flex-wrap items-center gap-3.5 mt-8">
              <a
                href="#services"
                className="inline-flex items-center gap-2.5 bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-sm sm:text-base px-6 py-3.5 rounded-full shadow-lg shadow-[#0F3A42]/20 hover:shadow-xl hover:-translate-y-0.5 transition-all"
              >
                <span>استكشف برامجنا وخدماتنا</span>
                <ArrowLeft className="w-4 h-4" />
              </a>

              <button
                onClick={onOpenDonate}
                className="inline-flex items-center gap-2 bg-[#B9862F] hover:bg-[#9E7024] text-white font-['Cairo'] font-bold text-sm sm:text-base px-6 py-3.5 rounded-full shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all"
              >
                <Heart className="w-4 h-4 fill-current text-[#FFF0D4]" />
                <span>ساهم في كفالة طفل</span>
              </button>

              <button
                onClick={onOpenAssessment}
                className="inline-flex items-center gap-2 bg-white hover:bg-[#F4FAFA] text-[#0F3A42] border-2 border-[#0F3A42]/30 font-['Cairo'] font-bold text-sm sm:text-base px-5 py-3.5 rounded-full transition-all"
              >
                <Calendar className="w-4 h-4 text-[#2E93A0]" />
                <span>حجز موعد تقييم</span>
              </button>
            </div>

            {/* Live Statistics Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-12 pt-8 border-t border-[#E1E9E9]">
              {STATS_DATA.map((stat) => (
                <div key={stat.id} className="bg-white/80 backdrop-blur-xs p-3.5 rounded-2xl border border-[#E1E9E9]/70 text-center shadow-xs hover:border-[#2E93A0]/40 transition-colors">
                  <div className="font-['Cairo'] font-black text-2xl sm:text-3xl text-[#0F3A42]">
                    {stat.value}
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-[#17282B] mt-1 font-['Cairo']">
                    {stat.label}
                  </div>
                  <div className="text-[11px] text-[#455B63] mt-0.5 hidden sm:block">
                    {stat.sublabel}
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Visual Hero Art Column */}
          <div className="lg:col-span-5 flex justify-center relative">
            
            {/* Center Circular Plate */}
            <div className="relative w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96 rounded-full bg-gradient-to-tr from-[#EAF3F3] via-white to-[#F4FAFA] p-6 shadow-2xl border-4 border-white flex items-center justify-center">
              
              {/* Decorative Concentric Rings */}
              <div className="absolute inset-2 rounded-full border border-dashed border-[#2E93A0]/30 animate-spin-slow pointer-events-none" />
              <div className="absolute inset-8 rounded-full border border-[#B9862F]/20 pointer-events-none" />
              
              {/* Logo Presentation */}
              <div className="relative z-10 text-center flex flex-col items-center">
                <img 
                  src={CALD_LOGO_BASE64} 
                  alt="مركز CALD لذوي الاحتياجات الخاصة" 
                  className="w-40 h-40 sm:w-48 sm:h-48 rounded-full object-cover shadow-xl border-4 border-white"
                />
                <div className="mt-3 bg-[#0F3A42] text-white px-4 py-1 rounded-full text-xs font-bold font-['Cairo'] tracking-wide shadow-sm">
                  عكار · المنية · الشمال
                </div>
              </div>

              {/* Floating Pill Badges */}
              <div className="absolute -top-3 -right-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl shadow-lg border border-[#E1E9E9] flex items-center gap-2 animate-bounce-subtle">
                <div className="w-7 h-7 rounded-xl bg-[#6FAF52]/15 flex items-center justify-center text-[#6FAF52]">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <div className="text-[11px] font-bold text-[#0F3A42]">مساحة 300 م²</div>
                  <div className="text-[10px] text-gray-500">مقر رئيسي مجهز</div>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-2 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-lg border border-[#E1E9E9] flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#B9862F]/15 flex items-center justify-center text-[#B9862F]">
                  <Heart className="w-4 h-4 fill-current" />
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-[#0F3A42]">كل طفل يستحق فرصة</div>
                  <div className="text-[10px] text-gray-500">رعاية متخصصة وعادلة</div>
                </div>
              </div>

              {/* Orbiting colored nodes */}
              <div className="absolute top-4 left-6 w-4 h-4 rounded-full bg-[#E0A83E] shadow-sm" />
              <div className="absolute bottom-12 right-2 w-3.5 h-3.5 rounded-full bg-[#6FAF52] shadow-sm" />
              <div className="absolute bottom-3 right-16 w-3 h-3 rounded-full bg-[#D2665A] shadow-sm" />
              <div className="absolute top-16 right-4 w-3.5 h-3.5 rounded-full bg-[#2E93A0] shadow-sm" />

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
