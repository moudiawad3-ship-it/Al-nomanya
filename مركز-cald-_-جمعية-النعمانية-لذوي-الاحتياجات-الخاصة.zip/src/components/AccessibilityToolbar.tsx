import React, { useState, useEffect } from 'react';
import { 
  Accessibility, 
  Type, 
  Eye, 
  Volume2, 
  VolumeX, 
  Minus, 
  Plus, 
  Sparkles, 
  Check, 
  X,
  BookOpen
} from 'lucide-react';

interface AccessibilityProps {
  onSpeakText?: (text: string) => void;
}

export const AccessibilityToolbar: React.FC<AccessibilityProps> = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(0); // -1, 0, 1, 2
  const [contrastMode, setContrastMode] = useState<'normal' | 'high' | 'warm'>('normal');
  const [isDyslexicFont, setIsDyslexicFont] = useState(false);
  const [isReadingRuler, setIsReadingRuler] = useState(false);
  const [rulerTop, setRulerTop] = useState(200);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Apply font size
  useEffect(() => {
    const root = document.documentElement;
    if (fontSizeLevel === -1) {
      root.style.fontSize = '14px';
    } else if (fontSizeLevel === 0) {
      root.style.fontSize = '16px';
    } else if (fontSizeLevel === 1) {
      root.style.fontSize = '18px';
    } else if (fontSizeLevel === 2) {
      root.style.fontSize = '20px';
    }
  }, [fontSizeLevel]);

  // Apply contrast mode
  useEffect(() => {
    document.body.classList.remove('contrast-high', 'mode-warm');
    if (contrastMode === 'high') {
      document.body.classList.add('contrast-high');
    } else if (contrastMode === 'warm') {
      document.body.classList.add('mode-warm');
    }
  }, [contrastMode]);

  // Apply dyslexic font
  useEffect(() => {
    if (isDyslexicFont) {
      document.body.classList.add('font-dyslexic');
    } else {
      document.body.classList.remove('font-dyslexic');
    }
  }, [isDyslexicFont]);

  // Handle Reading Ruler mouse move
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isReadingRuler) {
        setRulerTop(e.clientY);
      }
    };
    if (isReadingRuler) {
      window.addEventListener('mousemove', handleMouseMove);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isReadingRuler]);

  // Text-To-Speech reader
  const handleReadAloud = () => {
    if (!('speechSynthesis' in window)) {
      alert('عذراً، متصفحك لا يدعم خاصية تحويل النص إلى صوت.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToRead = "أهلاً بكم في مركز كالد وجمعية النعمانية لذوي الاحتياجات الخاصة في عكار والشمال. نحن نرافق أطفال طيف التوحد وصعوبات التعلم نحو الاستقلالية من خلال خدمات تقييم، علاج نطق، علاج إشغالي، دعم نفسي وتأهيل فيزيائي.";
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.9;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const resetAll = () => {
    setFontSizeLevel(0);
    setContrastMode('normal');
    setIsDyslexicFont(false);
    setIsReadingRuler(false);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <>
      {/* Reading Ruler Line */}
      {isReadingRuler && (
        <div 
          className="reading-guide-line" 
          style={{ top: `${rulerTop}px` }} 
          aria-hidden="true"
        />
      )}

      {/* Accessibility Floating Trigger Button */}
      <div className="fixed bottom-6 left-6 z-50 flex flex-col items-start gap-2">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2.5 bg-[#0F3A42] hover:bg-[#14535D] text-white px-4 py-3 rounded-full shadow-xl border border-white/20 transition-all duration-300 hover:scale-105 group focus:outline-none focus:ring-3 focus:ring-[#B9862F]"
            aria-label="خيارات سهولة الوصول لذوي الاحتياجات الخاصة"
            title="أدوات سهولة الوصول"
          >
            <div className="w-8 h-8 rounded-full bg-[#B9862F] flex items-center justify-center text-white">
              <Accessibility className="w-5 h-5" />
            </div>
            <span className="text-sm font-bold font-['Cairo'] hidden sm:inline-block">
              سهولة الوصول
            </span>
          </button>
        )}

        {/* Accessibility Control Panel */}
        {isOpen && (
          <div className="bg-white text-[#17282B] rounded-2xl shadow-2xl border border-[#E1E9E9] p-5 w-80 max-w-[calc(100vw-2rem)] animate-in fade-in slide-in-from-bottom-4 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-[#E1E9E9] mb-4">
              <div className="flex items-center gap-2 text-[#0F3A42] font-bold font-['Cairo']">
                <Accessibility className="w-5 h-5 text-[#B9862F]" />
                <h3 className="text-base">خيارات سهولة الاستخدام</h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition-colors"
                aria-label="إغلاق قائمة سهولة الوصول"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-sm">
              {/* Font Size Adjustment */}
              <div>
                <label className="block font-semibold mb-1.5 text-xs text-[#455B63]">
                  حجم الخط والنصوص
                </label>
                <div className="flex items-center gap-2 bg-[#F4FAFA] p-1.5 rounded-xl border border-[#E1E9E9]">
                  <button
                    onClick={() => setFontSizeLevel(prev => Math.max(prev - 1, -1))}
                    disabled={fontSizeLevel <= -1}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-white shadow-sm border border-gray-200 text-xs font-bold hover:bg-gray-50 disabled:opacity-40 flex items-center justify-center gap-1"
                  >
                    <Minus className="w-3.5 h-3.5" /> أصغر
                  </button>
                  <span className="text-xs font-bold px-2 text-[#0F3A42]">
                    {fontSizeLevel === 0 ? 'افتراضي' : fontSizeLevel > 0 ? `+${fontSizeLevel}` : `${fontSizeLevel}`}
                  </span>
                  <button
                    onClick={() => setFontSizeLevel(prev => Math.min(prev + 1, 2))}
                    disabled={fontSizeLevel >= 2}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-white shadow-sm border border-gray-200 text-xs font-bold hover:bg-gray-50 disabled:opacity-40 flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> أكبر
                  </button>
                </div>
              </div>

              {/* Color Contrast */}
              <div>
                <label className="block font-semibold mb-1.5 text-xs text-[#455B63]">
                  وضع التباين البصري
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => setContrastMode('normal')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      contrastMode === 'normal' 
                        ? 'bg-[#0F3A42] text-white border-[#0F3A42]' 
                        : 'bg-[#F4FAFA] text-gray-700 border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    طبيعي
                  </button>
                  <button
                    onClick={() => setContrastMode('high')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      contrastMode === 'high' 
                        ? 'bg-black text-yellow-300 border-yellow-300 ring-2 ring-yellow-400' 
                        : 'bg-black text-white border-black hover:bg-gray-900'
                    }`}
                  >
                    تباين عالٍ
                  </button>
                  <button
                    onClick={() => setContrastMode('warm')}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      contrastMode === 'warm' 
                        ? 'bg-[#E7B96A] text-[#0F3A42] border-[#B9862F]' 
                        : 'bg-[#FFF8EE] text-[#B9862F] border-[#E7B96A] hover:bg-[#FDF3E3]'
                    }`}
                  >
                    دافئ / هادئ
                  </button>
                </div>
              </div>

              {/* Dyslexia / Easy Reading Font */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs font-semibold text-[#17282B] flex items-center gap-1.5">
                  <Type className="w-4 h-4 text-[#2E93A0]" />
                  خط مسهل لعسر القراءة
                </span>
                <button
                  onClick={() => setIsDyslexicFont(!isDyslexicFont)}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    isDyslexicFont ? 'bg-[#2E93A0]' : 'bg-gray-300'
                  }`}
                  aria-pressed={isDyslexicFont}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${isDyslexicFont ? 'translate-x-0' : '-translate-x-5'}`} />
                </button>
              </div>

              {/* Reading Ruler Guide */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs font-semibold text-[#17282B] flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-[#B9862F]" />
                  مسطرة توجيه القراءة
                </span>
                <button
                  onClick={() => setIsReadingRuler(!isReadingRuler)}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    isReadingRuler ? 'bg-[#B9862F]' : 'bg-gray-300'
                  }`}
                  aria-pressed={isReadingRuler}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform ${isReadingRuler ? 'translate-x-0' : '-translate-x-5'}`} />
                </button>
              </div>

              {/* Audio Reader Text-to-Speech */}
              <div className="pt-2 border-t border-[#E1E9E9]">
                <button
                  onClick={handleReadAloud}
                  className={`w-full py-2.5 px-3 rounded-xl font-bold font-['Cairo'] text-xs flex items-center justify-center gap-2 transition-all ${
                    isSpeaking 
                      ? 'bg-[#D2665A] text-white animate-pulse' 
                      : 'bg-[#EAF3F3] text-[#0F3A42] hover:bg-[#D5EBEB]'
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-4 h-4" /> إيقاف القراءة الصوتية
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4 text-[#2E93A0]" /> استمع لملخص صوتي عن المركز
                    </>
                  )}
                </button>
              </div>

              {/* Reset All */}
              <div className="flex justify-between items-center pt-2">
                <button
                  onClick={resetAll}
                  className="text-xs text-gray-500 hover:text-red-600 underline font-medium"
                >
                  إعادة ضبط الإعدادات
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="bg-[#0F3A42] text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-[#14535D]"
                >
                  تم
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
