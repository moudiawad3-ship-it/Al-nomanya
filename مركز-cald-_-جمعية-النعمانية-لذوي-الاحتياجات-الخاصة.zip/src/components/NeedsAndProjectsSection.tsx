import React from 'react';
import { 
  HeartPulse, 
  ArrowUpDown, 
  MonitorPlay, 
  SunSnow, 
  ShieldCheck, 
  Grid, 
  CheckCircle2, 
  Heart,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { CURRENT_NEEDS } from '../data/contentData';

interface NeedsSectionProps {
  onOpenDonate: () => void;
}

export const NeedsAndProjectsSection: React.FC<NeedsSectionProps> = ({ onOpenDonate }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'HeartPulse':
        return <HeartPulse className="w-6 h-6 text-[#D2665A]" />;
      case 'ArrowUpDown':
        return <ArrowUpDown className="w-6 h-6 text-[#2E93A0]" />;
      case 'MonitorPlay':
        return <MonitorPlay className="w-6 h-6 text-[#E0A83E]" />;
      case 'SunSnow':
        return <SunSnow className="w-6 h-6 text-[#1C6670]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-[#6FAF52]" />;
      case 'Grid':
        return <Grid className="w-6 h-6 text-[#B9862F]" />;
      default:
        return <Sparkles className="w-6 h-6 text-[#2E93A0]" />;
    }
  };

  return (
    <section id="needs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <HeartPulse className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>مشاريع التطوير العاجلة</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            ما الذي نحتاجه الآن؟
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            احتياجات ملموسة وواضحة لتوسيع الطاقة الاستيعابية وتحقيق بيئة مثالية وشاملة لكل طفل.
          </p>
        </div>

        {/* Needs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {CURRENT_NEEDS.map((need) => (
            <div
              key={need.id}
              className="bg-[#FCFDFC] hover:bg-white rounded-3xl p-6 sm:p-7 border border-[#E1E9E9] hover:border-[#2E93A0]/40 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Icon & Category Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] flex items-center justify-center transition-transform group-hover:scale-105 shadow-xs">
                    {getIcon(need.iconName)}
                  </div>
                  <span className="text-[11px] font-bold font-['Cairo'] text-[#134A54] bg-[#EAF3F3] px-2.5 py-1 rounded-full border border-[#2E93A0]/20">
                    {need.category}
                  </span>
                </div>

                <h3 className="font-['Cairo'] text-lg font-bold text-[#0F3A42] mb-2.5 group-hover:text-[#1C6670] transition-colors">
                  {need.title}
                </h3>

                <p className="text-xs sm:text-sm text-[#455B63] leading-relaxed mb-4">
                  {need.desc}
                </p>
              </div>

              <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                <div className="text-[11px] font-bold text-[#6FAF52] flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{need.importance}</span>
                </div>
                <button
                  onClick={onOpenDonate}
                  className="text-xs font-bold text-[#B9862F] hover:text-[#0F3A42] font-['Cairo'] hover:underline"
                >
                  المساهمة في هذا البند ←
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Highlight Callout Footer */}
        <div className="bg-gradient-to-r from-[#B9862F] via-[#E7B96A] to-[#B9862F] text-white rounded-3xl p-6 sm:p-8 text-center shadow-lg">
          <div className="max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-right">
            <div>
              <h3 className="font-['Cairo'] text-lg sm:text-xl font-bold text-[#0F3A42]">
                كل احتياج هنا يعني فرصة أفضل لطفل وعائلته في عكار والشمال
              </h3>
              <p className="text-xs sm:text-sm text-[#0F3A42]/90 mt-1 font-medium">
                يمكنك التكفل بكامل البند أو تقديم مساهمة جزئية مع توثيق كامل وتقرير أثر مفصل.
              </p>
            </div>
            <button
              onClick={onOpenDonate}
              className="shrink-0 bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-xs sm:text-sm px-6 py-3 rounded-full shadow-md transition-all"
            >
              اختر بنداً وساهم الآن
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
