import React from 'react';
import { 
  Sparkles, 
  Heart, 
  BookOpen, 
  GraduationCap, 
  Users2, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { WHO_WE_SERVE } from '../data/contentData';

interface WhoWeServeProps {
  onOpenAssessment: () => void;
}

export const WhoWeServeSection: React.FC<WhoWeServeProps> = ({ onOpenAssessment }) => {
  return (
    <section id="who-we-serve" className="py-20 bg-[#F4FAFA] border-y border-[#E1E9E9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EAF3F3] text-[#0F3A42] font-['Cairo'] font-bold text-xs mb-3 border border-[#2E93A0]/30">
            <Users2 className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>الفئات المستفيدة</span>
          </div>
          <h2 className="font-['Cairo'] text-3xl sm:text-4xl font-extrabold text-[#0F3A42] tracking-tight">
            نرافق كل طفل بحسب حاجته الفريدة
          </h2>
          <div className="w-20 h-1 bg-[#B9862F] rounded-full mx-auto my-4" />
          <p className="text-base sm:text-lg text-[#455B63] font-medium leading-relaxed">
            نؤمن أن لكل طفل إمكانيات كامنة تنتظر الفرصة والبيئة المناسبة لتزهر وتنمو بثقة.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHO_WE_SERVE.map((item, idx) => (
            <div 
              key={item.id}
              className="bg-white rounded-3xl p-6 border border-[#E1E9E9] shadow-sm hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Header Icon with Colored Badge */}
                <div className="flex items-center justify-between mb-5">
                  <div 
                    className="w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 shadow-xs"
                    style={{ backgroundColor: `${item.accent}15`, color: item.accent }}
                  >
                    {idx === 0 && <Sparkles className="w-7 h-7" />}
                    {idx === 1 && <Heart className="w-7 h-7" />}
                    {idx === 2 && <BookOpen className="w-7 h-7" />}
                    {idx === 3 && <GraduationCap className="w-7 h-7" />}
                  </div>
                  <span 
                    className="text-[11px] font-bold font-['Cairo'] px-2.5 py-1 rounded-full border"
                    style={{ borderColor: `${item.accent}40`, color: item.accent, backgroundColor: `${item.accent}08` }}
                  >
                    {item.badge}
                  </span>
                </div>

                <h3 className="font-['Cairo'] text-lg font-bold text-[#0F3A42] mb-3 group-hover:text-[#1C6670] transition-colors">
                  {item.title}
                </h3>

                <p className="text-xs sm:text-sm text-[#455B63] leading-relaxed mb-6">
                  {item.desc}
                </p>
              </div>

              <div className="pt-4 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-[#0F3A42]">
                <span className="flex items-center gap-1.5 text-[#2E93A0]">
                  <CheckCircle className="w-3.5 h-3.5" /> برامج تأهيل مخصصة
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Partnership & Family Note Banner */}
        <div className="mt-12 bg-white rounded-2xl p-6 sm:p-8 border border-[#E1E9E9] shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-right">
            <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] text-[#0F3A42] flex items-center justify-center shrink-0">
              <Users2 className="w-6 h-6 text-[#2E93A0]" />
            </div>
            <div>
              <h4 className="font-['Cairo'] font-bold text-base text-[#0F3A42]">
                الأهالي والمدارس والشركاء المجتمعين
              </h4>
              <p className="text-xs sm:text-sm text-[#455B63] mt-0.5">
                شركاؤنا الأساسيون في رحلة كل طفل نحو التعلّم والاندماج في المجتمع والمدرسة.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenAssessment}
            className="shrink-0 bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-xs sm:text-sm px-6 py-3 rounded-full transition-all shadow-md"
          >
            استشر فريق المركز في حالة طفلك
          </button>
        </div>

      </div>
    </section>
  );
};
