import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Check, 
  Send, 
  Baby, 
  Phone, 
  MapPin, 
  FileText,
  AlertCircle
} from 'lucide-react';

interface AssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AssessmentModal: React.FC<AssessmentModalProps> = ({ isOpen, onClose }) => {
  const [childName, setChildName] = useState('');
  const [childAge, setChildAge] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [conditionCategory, setConditionCategory] = useState('طيف التوحد');
  const [preferredBranch, setPreferredBranch] = useState('حلبا — عكار');
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const resetForm = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#E1E9E9] text-right animate-in zoom-in-95 duration-200 my-8">
        
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#EAF3F3] text-[#0F3A42] flex items-center justify-center">
              <Calendar className="w-6 h-6 text-[#2E93A0]" />
            </div>
            <div>
              <h3 className="font-['Cairo'] text-xl font-bold text-[#0F3A42]">
                حجز موعد تقييم وتشخيص للطفل
              </h3>
              <p className="text-xs text-[#455B63]">
                فريق تشخيصي متعدد التخصصات — مركز CALD
              </p>
            </div>
          </div>
          <button
            onClick={resetForm}
            className="text-gray-400 hover:text-gray-700 p-2 rounded-xl hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#6FAF52]/20 text-[#6FAF52] flex items-center justify-center mx-auto mb-2 animate-bounce">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>
            <h4 className="font-['Cairo'] text-2xl font-black text-[#0F3A42]">
              تم تسجيل طلب التقييم بنجاح
            </h4>
            <p className="text-sm text-[#455B63] leading-relaxed max-w-sm mx-auto">
              شكراً لكم أ/ <strong>{parentName}</strong>. سنقوم بالاتصال بكم على الرقم <strong>{parentPhone}</strong> خلال 24 ساعة لتحديد اليوم والوقت الأنسب لجلسة التقييم الأولي للبطل <strong>{childName}</strong> في <strong>{preferredBranch}</strong>.
            </p>
            <button
              onClick={resetForm}
              className="w-full py-3 rounded-full bg-[#0F3A42] text-white font-['Cairo'] font-bold text-sm hover:bg-[#14535D] transition-colors mt-4"
            >
              تم
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="bg-[#EAF3F3] p-3 rounded-xl border border-[#2E93A0]/30 flex items-start gap-2 text-xs text-[#0F3A42]">
              <AlertCircle className="w-4 h-4 text-[#B9862F] shrink-0 mt-0.5" />
              <span>جلسة التقييم تضع الأساس العلمي لخطة التدخل الفردي الخاصة بطفلكم ومتابعة تطوره.</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  اسم الطفل:
                </label>
                <input
                  type="text"
                  required
                  value={childName}
                  onChange={(e) => setChildName(e.target.value)}
                  placeholder="اسم الطفل الكريم"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  عمر الطفل (سنوات / أشهر):
                </label>
                <input
                  type="text"
                  required
                  value={childAge}
                  onChange={(e) => setChildAge(e.target.value)}
                  placeholder="مثال: 4 سنوات ونصف"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  اسم ولي الأمر:
                </label>
                <input
                  type="text"
                  required
                  value={parentName}
                  onChange={(e) => setParentName(e.target.value)}
                  placeholder="اسم الأب أو الأم"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  رقم الهاتف للتواصل:
                </label>
                <input
                  type="tel"
                  required
                  value={parentPhone}
                  onChange={(e) => setParentPhone(e.target.value)}
                  placeholder="مثال: 76801069"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs text-left focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  نوع الحالة أو الملاحظة:
                </label>
                <select
                  value={conditionCategory}
                  onChange={(e) => setConditionCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs font-semibold text-[#17282B] focus:ring-2 focus:ring-[#2E93A0] focus:outline-none bg-white font-['Cairo']"
                >
                  <option value="طيف التوحد">طيف التوحد (Autism Spectrum)</option>
                  <option value="تأخر في النطق والكلام">تأخر في النطق والكلام</option>
                  <option value="صعوبات تعلم وقراءة">صعوبات تعلم وقراءة وتشتت</option>
                  <option value="متلازمة داون وتأخر نمائي">متلازمة داون وتأخر نمائي</option>
                  <option value="تأخر حركي وعلاج فيزيائي">تأخر حركي وعلاج فيزيائي</option>
                  <option value="تقييم استكشافي عام">تقييم استكشافي عام</option>
                </select>
              </div>

              <div>
                <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                  الفرع الأنسب للمقابلة:
                </label>
                <select
                  value={preferredBranch}
                  onChange={(e) => setPreferredBranch(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-xs font-['Cairo'] bg-white font-semibold"
                >
                  <option value="حلبا — عكار">فرع حلبا — عكار (المقر الرئيسي)</option>
                  <option value="المنية">فرع المنية</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-['Cairo'] font-bold text-xs text-[#0F3A42] mb-1">
                ملاحظات إضافية يود الأهل ذكرها (اختياري):
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="أي تفاصيل تود مشاركتها حول استجابة الطفل أو تشخيص سابق..."
                className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs focus:ring-2 focus:ring-[#2E93A0] focus:outline-none"
              />
            </div>

            <div className="pt-3 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-xs font-bold text-gray-500 hover:text-gray-800 font-['Cairo']"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full bg-[#0F3A42] hover:bg-[#14535D] text-white font-['Cairo'] font-bold text-xs sm:text-sm shadow-md flex items-center gap-1.5"
              >
                <Calendar className="w-4 h-4 text-[#E7B96A]" />
                <span>تأكيد طلب التقييم</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
