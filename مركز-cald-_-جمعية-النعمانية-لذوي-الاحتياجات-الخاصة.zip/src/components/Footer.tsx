import React from 'react';
import { 
  Heart, 
  MapPin, 
  Phone, 
  Mail, 
  ChevronLeft, 
  ShieldCheck, 
  Building2,
  Lock
} from 'lucide-react';
import { CALD_LOGO_BASE64 } from '../data/contentData';

interface FooterProps {
  onOpenDonate: () => void;
  onOpenAssessment: () => void;
  onOpenVolunteer: () => void;
  onOpenExport?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ 
  onOpenDonate, 
  onOpenAssessment,
  onOpenVolunteer,
  onOpenExport 
}) => {
  return (
    <footer className="bg-[#0A2429] text-[#A5C7C7] text-right border-t border-white/10 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={CALD_LOGO_BASE64}
                alt="شعار مركز CALD"
                className="w-14 h-14 rounded-full object-cover border-2 border-[#B9862F]/40 shadow-md"
              />
              <div>
                <h3 className="font-['Cairo'] font-black text-xl text-white">
                  مركز CALD
                </h3>
                <p className="text-xs text-[#E7B96A] font-bold font-['Cairo']">
                  جمعية النعمانية لذوي الاحتياجات الخاصة
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#A5C7C7] leading-relaxed">
              مركز متخصص في عكار والشمال منذ عام 2018، يقدّم خدمات تشخيصية وعلاجية ونفسية وتربوية لأطفال طيف التوحد وصعوبات التعلم والتأخر النمائي لمساندتهم وعائلاتهم نحو الاستقلالية والدمج.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <span className="w-6 h-1 rounded-full bg-[#6FAF52]" />
              <span className="w-6 h-1 rounded-full bg-[#2E93A0]" />
              <span className="w-6 h-1 rounded-full bg-[#E0A83E]" />
              <span className="w-6 h-1 rounded-full bg-[#D2665A]" />
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-['Cairo'] font-bold text-sm text-white uppercase tracking-wider">
              أقسام الموقع
            </h4>
            <ul className="space-y-2 text-xs font-semibold font-['Cairo']">
              <li><a href="#about" className="hover:text-white transition-colors">من نحن وتاريخنا</a></li>
              <li><a href="#who-we-serve" className="hover:text-white transition-colors">الفئات المستفيدة</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">الخدمات السبع</a></li>
              <li><a href="#tour-gallery" className="hover:text-white transition-colors">جولة ومرافق المركز</a></li>
              <li><a href="#needs" className="hover:text-white transition-colors">مشاريع التطوير</a></li>
              <li><a href="#get-involved" className="hover:text-white transition-colors">كيف تساهم وتكفل</a></li>
            </ul>
          </div>

          {/* Direct Actions */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-['Cairo'] font-bold text-sm text-white uppercase tracking-wider">
              بوابات المشاركة والخدمة
            </h4>
            <div className="space-y-2.5">
              <button
                onClick={onOpenDonate}
                className="w-full text-right py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-white border border-white/10 transition-colors flex items-center justify-between font-['Cairo']"
              >
                <span>كفالة طفل أو تبرع لمشروع</span>
                <Heart className="w-3.5 h-3.5 text-[#E7B96A] fill-current" />
              </button>

              <button
                onClick={onOpenAssessment}
                className="w-full text-right py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-white border border-white/10 transition-colors flex items-center justify-between font-['Cairo']"
              >
                <span>طلب حجز موعد تقييم لطفل</span>
                <ChevronLeft className="w-3.5 h-3.5 text-[#2E93A0]" />
              </button>

              <button
                onClick={onOpenVolunteer}
                className="w-full text-right py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-white border border-white/10 transition-colors flex items-center justify-between font-['Cairo']"
              >
                <span>الانضمام لفريق المتطوعين</span>
                <ChevronLeft className="w-3.5 h-3.5 text-[#6FAF52]" />
              </button>

              {onOpenExport && (
                <button
                  onClick={onOpenExport}
                  className="w-full text-right py-2 px-3 rounded-xl bg-[#E7B96A]/15 hover:bg-[#E7B96A]/25 text-xs font-bold text-[#E7B96A] border border-[#E7B96A]/30 transition-colors flex items-center justify-between font-['Cairo']"
                >
                  <span>📦 تنزيل واستعراض كود الموقع كاملاً</span>
                  <ChevronLeft className="w-3.5 h-3.5 text-[#E7B96A]" />
                </button>
              )}
            </div>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-['Cairo'] font-bold text-sm text-white uppercase tracking-wider">
              فروعنا في الشمال
            </h4>
            <div className="space-y-3 text-xs">
              <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                <div className="font-bold text-white mb-0.5 font-['Cairo']">فرع حلبا — عكار (المقر الرئيسي)</div>
                <div className="text-[11px] text-[#A5C7C7]">هواتف: 78913443 | 70120915 | 26695920</div>
              </div>

              <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                <div className="font-bold text-white mb-0.5 font-['Cairo']">فرع المنية (الشارع الرئيسي)</div>
                <div className="text-[11px] text-[#A5C7C7]">هاتف: 76801069</div>
              </div>

              <div className="text-[11px] text-[#E7B96A] font-mono">
                البريد: Cald2018@hotmail.com
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Privacy Statement */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#7A9E9E] text-center md:text-right">
          <div>
            © 2026 <strong className="text-white font-['Cairo']">مركز CALD — جمعية النعمانية لذوي الاحتياجات الخاصة</strong>. التوحد وصعوبات التعلم، عكار والشمال. صُمّم بمحبة لدعم كل طفل يستحق فرصة.
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <Lock className="w-3.5 h-3.5 text-[#B9862F]" />
            <span>نلتزم بحماية خصوصية الأطفال وكرامتهم وفق أسمى المعايير الإنسانية.</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
