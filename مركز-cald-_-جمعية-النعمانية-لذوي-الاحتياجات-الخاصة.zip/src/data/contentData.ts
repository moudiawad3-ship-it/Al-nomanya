import { ServiceItem, NeedItem, BranchInfo, StatItem, GalleryItem, FAQItem, SupportOption } from '../types';

export const CALD_LOGO_BASE64 = `data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wgARCAFPAQQDASIAAhEBAxEB/8QAGgABAAMBAQEAAAAAAAAAAAAAAAEEBQIDBv/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/aAAwDAQACEAMQAAACtaHouAzsAAAAAAAAAAAAAAAAAAAmAArdJ7hQAAAAAAAAAAAAAGfoY1nI1jW9adzGwUAAAAAAAAASRXsZdk2c6bnaROdsTbxrnkazeu17GNjhatXzaxeu4mxL2JoAAAAAABka9CylMTrGnYqW87ZOtlHiidY1/Tz9MdFexSsoTE6xGvm6+dBNAAAAAAAOehi82K++fpsY2znU5enRWjKNY2e+esdGdo5NnlExrGla47xsFAAAAAAAAz6ejn6x3sYmqvtVtVZc4axr+lG9jbG2cWyO/O1qaQxscHbL7s0UTKAAAAABGLt5Nz42Kte36ahnznfbmd8rWlS9+W+cu95ZV9bN1+mQaZOhlXIazpWfD3x0AAIEgedWlc7U42mvtn6Pzs3Q5lj1QkrbxL057PNS55cwllFjwnpm0cezlSqGsLHnrLIzoACEgDMr26m8PXyg3PlPqPl+Xq8nTPp5TKcy0Zmh9Hx6efjCXOQlVihcyPocExe1mx6mdgAAAAeGXt5tzVJ1nTw9bnHfDXOXSLHHXbxZ2hE+f1arL0vHnpUr2abLbmjn2fb158tGJUJQAAAAHh7jEWK+8d6mPpRSi9T68OXS54juOevH16jy9p47hOOY77Wb1G/q2xnYAAAAAAFXO2MfWAsc9QWJoXd8juOWuXXHHTw576VJ0NjM1s6CaAAAAAAAjG2qNlIawBHhYHFjw8k9vFxnVjqj61agsu3uO8bBQAACYIBIAHl6jEWqu8AipbzZbSKy1/T15Opn1LdmropaGdgAAAAQCQAAcZWxxZjrda55ztFXh5XEcR6LKF6YJ16GnnQTQAAAAgkAAAADjsUKuzFmJOpxZnRp+plWNFLz0SgAAAAISAoIIJVLNdKN0lX5izOZ62XGJzW/E5+bfnxyLNyaF06cecvu8PcmAAECYlQQBz1SM3WzW82q8exQW8qzXtUOZYjR840sjWxF0aXnNnlq0veOaMe1eX0OXqShmgICQAACqWlX3rtX8o59Y51Lqh6RbefEvpR9Pavd4cFrOveCWZpSXFazKAORKVBAAGdoqw/PbWY/W2PmrW2Me1eRkRsDIr73hWT47dkwefoBg2NaDA+gpXYESwjoSKCAf//aAAwDAQACAAMAAAAhN/8AffffffffTffffff/AH33Xv8A/wDfffbdffffffffeEV/fvvfbdfffeaRdCwX/ot/vfWffffeKVfiXrac/wD321X33251dyVb5V/3331n3331rykV+Nz7rD72nH332vXUB5t/3KH73030PCXXiJT134oj333H0AR7ioH364Qb733030vmIWQYss1IX3333334g0or6z4oX3333333+lXI/wClydv99999B99K99BBwzd399991999+09/Q9Zf99999599999yQ2R9X99999tB9999uOoYU+99999Z89+842rgupRy2d99M996sw1MP8QrmV99hV9960uw9ik8JZ29pQd99soAw3jYwQwf4p099//aAAwDAQACAAMAAAAQWc+u+e+++++6BBBBB8+++28/0++++6JBBB+e++++nTe99++6JBB+64y//d/9ZJ9+2vBB++/6hcKc4AaU+++pB++9d+bi8tY/+e++uBe++51sCD7td9KlW+N+++/gb0j5nePMu+qN+iL2b1Fhggxa4WuOx+N0g1OdxHRG9JCO6x+PW0uWABBTu5yC++M+poPlGF2VgXCOOi+x+8PaciQXpQqe+W++x++YCCIolyJX+++O2x++9gCW/FqA6y6++uN+++6CoiVVYS+u+uv9++++Nc+YmVu++2+5A+944qAQW+N29e+uwB+ulKXVmECihU6+JJB+v4LNrfO4dnBSmQhB+43ddKsxCO9hTBgBB//EACcRAAEEAQQCAgIDAQAAAAAAAAEAAgMRIQQQEjEgMBMiBUEjQFFh/9oACAECAQE/AJdQ55/5/X4u8j6oxZ2cKPsYLKLBSqlEgnmyhk0g1PbWfTGc7PFFRd7O7TB9tpDivSDRQ6UnajNHZ3aiGdnGz6mHClGLTO9nDKiT8DYC0YzSIrziP6UkjAKKZK20CCMLVa2GI04qP81prpfO2QAsN7Mb+9nHPi2O05lJzuAsIu5ZO0s744zw7WpbJzuXs7aDVuglA/RTfsgMUnOrHk04RFrUGgrQDip5fjZzpa3VN1DgQOtmdhaQfxglFwCJs+Ubv1tLCZPqEPxcxUOnLIeFC1rvxkphcSVqNI6HJKh0DpG8rUH4p5kGVH9BScbPmDSBsJwIPIKCYPbtrdTE6JzQcp8UcmHBMYGji1aWHiLKk69MZxs1xYbCZMHDK1Wha0OlQBPS0+lr7OVKQ+mN1Y3P+hSOc+PiVFCxgVoJ5s+kGsppsbFHYdp5pvrY/iuQKq1SoIBSOvHsBpCUr5AjIF8pPmfAtIRaQMhcHVa4ikYaJTQCUyMuKc2jhAEmqRBHfm3tEtIrkuTeJF2m04d4X0qrRlFlQC3Kw04cjTnDiraxxypXA9bnwaLwuJBXAnKBfVIsNWqJQ5t6XApvMdItJyiCO/NppfIEZAjIi+xS5hCRGQISj/EZM4CkcHVXl//EACkRAAEEAAQFBAMBAAAAAAAAAAEAAgMRBBIhMRATIDBBBQYiMkBhcRX/2gAIAQMBAT8AgwbIv7+Pnb+BMaCGhTDbe5I4gaJsjr1QNi1PtwjFNRNJz3EqJ5doUOxKLCtM+qm+q8puykNNX7UI89k6ik4UVCdFKPigU3ZTHRfpMFDtSCnKE+FJsvKYbapk0fJBE1uuaLQ165h5WHwk0htoUvp0+XZPjcw0RqsPC9w0CkwUxKjjLSc3CZ3hUEzbpfLR0TJA5YTDDEShh2TImsFNCohYzCNlGatUGcsZapWp4w9t+UTScbNqJlmz1PGqaaNr0Noe938RjrROLGnKSsQ7lsLqU0/MIKtE6Kd1Gk1uYoChXVK3S+Hp2PZg3cx+1J3u/BeAVi/UmzY7nAnLak9zYWWPlNBtQYpsugUuPbG7KQv9Fp0AThzDYTGZR1kXonCjSZTmljlisOYn14WVQxPDg4qOZ8X1Ke5zzZTG0ovt2ZhR4OYHiipcMWGwo5iaaqQYAiVC3z2Zm2L6OQ3NYQBWSuDG0OyReicKPBg3KAG6tEitVELPbfHmRaQmupZyrO6Lid1C07nqHURadCDsuS5CE+UIQN0B1DoDgdlYOxQcLpF2qEl0iaFpzwBaDrFqwNUCDt0Hi7ZAOHhZXZgQEbB2XyvZBh0Uppq+TgNEPi02qcQowQOI6CaQIVhZWg2g4WrCOU7rME7Kd1mA0QIPWRaylZFkQZRRaUWLIVkKyJgrgEeP/8QAPRAAAgEDAQUFBQYEBgMBAAAAAQIDAAQREgUQEyExICJBUWEUMDJAcRUjM0JSgTRTkbEkNWJygqFUYMHw/9oACAEBAAE/AobR5eZ7q1FCkQ7o/wDbenM017GpwMt9Kiuo5TjofX5+9my/DHQdd9tJxYQfHx+ec6pGPrv2f8L/AF+Yubng8h8Rr2yb9Q/pVtdcVtDdd56djZ/5+xc3ZBKR9fE1x5f5jf1q3uyzaJP2PyV2c3LenLcjFHDDwpW1qGHjvcYkYeu+zTTbj1575G0RM3kOxE2uJW8x8jccriT677L+H/ffc8rh/rvt/wCHT6b704tj69i3Gm3QenyN/HzEn7HfYPmIr4g77sYuW3w8oU+m/aDd1F9c74Y+LKF+SkQSIVPjTLpYqfDdAWE6afPffD/EfUb4ucKfTffH74DyG+xj0xavFvk7wYuT6jdGcSqR579ofk3xrojVfIb7ltVy39N8S6IlHp8ntAfeqfTdD+Mmemd9+uYg3kd8D8SFW3yfiN9d0S6pkX1+Uvo9UYcfl328vFiB8fHdfSaYtP6t9g/N0/fd0pjlifPdYrmfPkOxJIsSamqS7lc8m0jyFR3sinv94UDkZHvSMqRXTdZyaJseDct20BzQ77H8c/TdeSaIcDq27GaghEMePHx7E8vFlJ8B032TZgx5HHvrlNE7D96d1jGWOKN7g9xf619t3H6I6ba4mi0yxYPmtLIsg7pzus4+GhkblmjP5CpRxjlqNuPA1w2WRcjlnsXT8OBvM8uxax8OEZ6nmfde0RA/iCgQwyDnftPEcYl8Ry+tO5kbLdgEqcjrWz+DPDxGzrXqtMdXZjfV16776TMgT9O+1g4j6j8I91fSHUIweXjuR2jOVOKt5+Mvkw67trz8S74f5U7WzZViaTW2BiodoRzTcPSVz0PZXkc7pZOFGWPhRJZiTuhiM0mnw8TSqEUKOg91e/xJ+m+3k4cyn9t1ydV1K3+s9oKW6KTUAPtEeOuodpfhFXsup9A6DcFLMFHMmoIhDHjx8fd36/eI3p2EOqIH0qUYlf69jHpu2V+JJ9KW3iR9aoA3n2mfhQFvIUTk5O6xj6uR9PeXURli5dRz7Fm2bYDy5VeJounG+1CYP6vWnK6Tq6btlfjP9O3fZ4I8s7rKHU+sjkPfXsYSXI/NvsZO8yefOtoQRNhypLdK9mQ+Yr2Vf1NSQrGcgc6Khhg9K4Ef6KC8M5iOg+lcW5/nGotfCXifH41dtMrLobStcS4/nGuNcfzjXFlbus5NR3Pc0SjUlLZRk6g5KUAFGAPfXMHGTl8Q6URg4O6N+HIrVLHxYitFdJwRz3YrG+TUMFeopdpyeMHP/dTSvN8QAHlWKPIZpfPdYHuuvl8heJpnz4Nz32k4dAhPeFXca6deQCKArFY3YrFaRvZtRx4ChusV+7LeZ+QvkzCG8j2CS3Uk0snC5N8H9qHMZHSsURWOw8ms4Xp50BjfCnDiVfkJV1RsPTskZoM9u3d5r+mopUmXKn6jcfAbnZUXUxwKaQzdOSf3oDG+3TXOo+RfJRgOuKIIOCMHskZp4yrakOD6VFekcpl/5CjIrSppIK4NSXajuxDU3/VaWdtUhyaHYsE5s/7fJX45o2O2Ywaa3yfSojFz0Mvd60t5EzsB0UZzXtUkkqqv3erpyzUFw5maCX4h4jfEnDjVfkp4uLEV8fCuhx2WuHe54MOOXVjVtO0gfXjuHGfCpnErpCrcm5t9Kh1EMg6FhqHpSx8W8njBx1/vTDTtGEeQApv82XH/AO5brKIPIWP5flL2LRJrHRuzs/ncSfSriFpCmlgNPgR1qFOPdS6z8P6RitnD7yWoWVNoyl2A61NHI12s0enAHxE8qt7ZklaaUgufLdYj7onzPykkYkTSaljaJ9LdhoJ4LniQjUDUSS6+JMefgo8Kt4HiuJSR3T41FEkWdAxmngif4kFfZw4mQ/d3wpw4VX0+VkjWVcMKksXXmh1CipU4YY9zaxcSTJ+EfMSRJKO8KksWHOM59DToyHDKR2VRn+EE1HYu3x90UiBFCr0+aIz1Gaa1hb8uPpXsEfm1Cyh9T+9LbxL0QfOZ54rOaDq3Rgf3oOrHAYf13MwUZJAHrvyM4zz+SJAXJ5Coto2sz6ElGrwz407rGhdzgDrQ2tZlscX98UrB1DKQQfEVPewW3KWQA+VQX9tcNojky3lV1aR+2C6kuTGvTGasLYW8DlZuIH5g1sP+Lm/2/wD2tlf5tJ/y/vu2pDFNEgkm4Xe8fGg0cVsG1/dqvxHyqbaU93JwrQaF/Ua2dYey5kaUu79fKndYkLucKKjmjmXVGwYelT3kFt+LIAfKoLyC5/CkBPl2z23UOhVhkHka2tZQ20aSwjRzxioSLuxTXzDp3qk2RatEQqaW8GzWxJSDLAT05irSNLzaUvtHPqcedLEkG3kSMYUN0/atuH/DIP8AXViR9mxc/wAlbD/jJv8Ab/8Aa2V/msn/AC/vu29+FD/uNRxrcbMSM9GjA5Udgx/zn/pVs8uz9pezliUJxW1P8un+lbGP+A+jGrZFv9qSmXvDmQPOmRbTbUaw8hkcvfX9m94E0y6MV9hOT37nl9K+wnB7tzy+lfYkv/lf9VZ7KNrciZpQ2B5Ve7Pt3uGdblYn6sCajtzNe8GOXVz+Ol2E+r7yfl6CjsKXnpuBp+lWGz1sgTq1O3U1abNa2vGnMgIOeWKzgc621cRycJEYMQSTil2LKUBFxpyOmK+w5v8Ayv8AqoNislwkjz6tJz0ratzELOSPWpduWkVa7KlubcSiUJq8MU2w3TBhuO968qs9k8KbjTSa28O0fe3WyobqYyszAnyq1sIbTmgJY+J7LrrjZD0YYqDY9tDIG7z46auw2x4HnaVmc6jkilUIoVRgDtn3N7M0KoVmjj58+J41ZXPGhYmVXKnmVGBSyo8esOCvnUV5b3DaYplY+lRXEjbSnhJHDRQRX2lZ69HtCZqeW4WfTG8OHHc1dT5011KNotDkaRFq/etnTvc2aySHLc6leRFykes56ZxQuMLmYcLv6VyetW1xJLeXUbEaYyNNe1QcEy8VeGPzVBdwXOeFIGIo7StFk0GddVGRRjLDvdPWm2hapJw2nUNV/cvAkRjI7zgVFcu1/cRMRoQDFJtC1kl4aTKX8uyefub2GX2yG4SLjKgwUqGWa39pVrSX7xs90dKBuPswWS2sus+OOVF2M9vJFZSrwfi5daW4kW8muGs5tMqhcVouPZWh9lbgluunvAVLNLJPBKtnLpg8/GoeLcX8lxwHReFp71bJRo7BAwKnJ5GopZ7JpY5YJZMuSGXnVzLLeNAq2sq6ZA2WFapbS+um9nkcSYIKULSf7LT7o5WXWY/MUl3p2m0i2sg+706AOdBLgW8kaWrcJj1Ze8KupJpooljtZl4XiRXL2IwLs+TWRzYjxpjPcR21v7PKGjYZY00Er3N+FUgundNa/vbGI2zRMj9T49gn3c0Anj0MWA/0nFQwCBSoZjzz3jn3LDUpXzo2am1EGuQDz1c6trGO1LMpZnbqzHJ7LLqUr51Ds2OKYSs8kjL01t03sfcf/8QAKxABAAIBAwMDAwUBAQEAAAAAAQARIRAxQVFhcSAwgUCRobHB0eHw8VBg/9oACAEBAAE/Id4eu7spwjy8v/gcV/8AGqBSg5Z80IYlIr0Pry2T+VoNI8ktfZj64/UVqlLgH1FUzbF8Ed78CLShxTnXJeI4Xzraumz0I3h8MyXkgzRnH8v0XZ1IWbqyuFswXr2oetl5zejEu88ulo2b7zz8fQ3EnXoRKb4YagGas9XTeoIabRUt/oWP7P8ARDQOpnXzOnTiGn26+YrUo2274gUUbfQ7Jwib4VOlwW2vk1Qs7DpxHY7dbtYhb/o+jvnQf20TegJxoM45zplaOZ2QDW49HQ9p2DB9H5F+/Sp0rev+Cr166VT51yfv/XTvwPpF3huO2vTzgd9CGtq+0NLPiNFBbidyi6bFx+Z9DhfB1iFTggSPm7kM0sSz08+wXWColkd9FJPM8xidPk1v2tN+lYvjSyA3YQPcur6H7Rfy1a9707jNPmYTHfmU7ttjPhPmIHhkbnxLofUS52loPSF1u8Mb7CitorfPJDgo5Nt/ReB4GvEb2UhaLeOsaR+7Kwh21vFOBDRr6dvQfWhFkBKba4qt24JWtSvSw1pjbJ86tW/vvtWgAL7oy+9doec4TRqjhr5da0qUqsHM34Sm5/jSpUqKuOIHw51Y4WXLpSGz4CGCHrHX8NWuTcXbxFxOWL/UlSpUqVLbEmaLqMA8TSpUqVM/BM3dXzoYOyCCPMuvtocBp6O/95S3r/WVKlRQbvtKn439YlbOBKlaVoSEETccs+Yob9i3uMacbvHTeeSkd/m9GWDCH4EFg1MxLVmH+e8v08kqM7kJdXiovlge6Mxgyd9aE9iXnB2NR2h4mf8Adl92FWtyo9ridtGZy4XkR/qSEAhpkEz8pwZuf88j/SkcdrmqlKvRV8kJsGQ/uGTAcHvVVq/yIjhSO2nbRz4h9YLHvGSoNyVqVKhueSyIxbzSKihcJ4QCLYmaoy6P0CE+guhsasRbryRN5Td5lhZqJoom0o4laYP5usFGlX0GKgM/idRRsUTppzMNy/uL7zQEFbOih0VKiYifJuqVtN52AM/QWbypXX0VMy2Drr9pvxHkJVzd1LlTsIHeLUM3zFbXBWLt+Pcd/SNyCCO3Bx6RGZbIfMfgc/qRBULdxzuJ4QsB3tjxBU41ynbZ7jv6jCbrF9VXvOBhb1VzEBR0HaXZF0+0sMD47qwSTNQVemdjeGZwZ8/RB5h5RFFuelVV4K4J1NjaoVTIg8eIQHzBl+kpguUx2RU222PEfxC9GQEpXn6SpDqefSsvdt+Y9FK84jGLCsAYaqZKL+YLBUiveYjEYHwATEGU/wCue47ew3238RUHh4TXZuKb42/Ziq4rWwE6Wpt3lvtZrcsba81EyovdQ06xGXuPs5bujyTELoOGX4LokfXtHMuV89Pd59utX9Hkm2F4GW5Hc9F1MUr2IwLOhuwOKHuMPdM0A6JM63fCPRjzDbnmj9ReYAFBj3n3amQveoAWIxxGjpFoB6Gju5hVLlwZ1U3OT3OfU6agtXiH7I0BXwuCJPaeJ+rNqZYbCYj/AGTlv4lLPUCP5hm8OJmuGP07eVooZea0CLgwdkO7Atl3TeLupGB+/ESmFsf8YcAlq7EzGmrigGWwy/YiCEt9j9vX0Q9VWR0dSWG7cH5GUdoinjMSPVuFucFaDw8zK14W1a6r+ohUyk3VwecX3dptoBn2juN+HDif4HSOPT54YlHH2kIleh2R2Z/a+YZSwypgjSx2XQTv2uvfc9TibvrOM23hzKettw7/ACxUxXxn/Mp4fd/MPyoUVy/MZB+5nnfEpeajoxzFCl+b+WER0AX/ADHVs2wBCE7hpu3EIqgyrB7fw2EPzkZcfmdn938wF5Cg7a73BHvSWjeYI4siX3g9YTNPwSMZzbB1636nxD2K9AEqLwiThAvbWlamwpCrvEGsrCKv4lSpU3PZ0D+YNQVASvUqJvD18rTuDoQWPp+qEw3Xa4jEj3FKDYSqq+8qsyaelwYSSqbP6TZa2VB0kQoVzCOHRGx1mPdkFleH5lY4WG0NwjTbEcG/gRoWGqmCvZd/CZuLVXswJy9avDL8XO2ZlRXd49Kt2h7BLLFjZecxm1IMhYlYMM4qXcpSvZWkaSIAzjrAyZ4MZm3mBW73IJWJu8/FlZsFwHeGRsTiMtbQUCZs+AviWe67N4ZnS6qM7sW+xS1QFTtyNqinHr+6rhmaJaMQLYBSha6xuMCI1BrxEIezmxA3YxL6W7upUqVKla1BQugmGVdDj1b3nNAhyVKlSpkRKVZvN3Q2zVRjmED1f//EACoQAQACAgEDBAEFAQEBAQAAAAEAESExQRBRcSBhgZEwobHB0fDhQPFQ/9oACAEBAAE/EGy+ZArxH8wY8GXPkZR/46iV+MAoCjiUdoa/8tTP/wCDxM/+DHUyILUoDvHQqNNEfLuBVPQVfiXfft+N1C+fW7/HVcC6uzx4Il7zEEUSxMVEze67uc/OPyP5bOpFAt0R1Nrr+YR1FM5IPdG/Qz7mms+tO34nWJR0Mo00W/MW0o4CqYIquKV2Z556in3RCje794dHTqrvzT11K2K1ibdj+5buXuf01GnVqOG+0Zuqr18/idt3Qe1H9sRwq+ZoBw+OI1dnPyR3OSXkaHxfQab7QKCsx+h+3W3mlU81j9ZeybS33uMLroIHsmpe7kV59b+I0Iujwh/ZMdBulPahfR1DErf7CLNkSt3SO5xM4U+Tzb+3RuPKrrMIqgVPwO4deIdT3igeAE4dr/dppLAjAaUh2jz03Mh4fcdOUM0o/ivqFRygewV/LAqeNwj7aP2Ln71BAMNHYqpXrqG317gElgvs8PxNm28w10o9AVNWOR+IYOlXtA906KWhh6f2zqZ2x+1Yx3KbW632GiV+Hmz0V6PMrMr5lq37dGizxXOYXkx1CV5M/atdKFuVEAls+Yr/AO9OJmO8bwHQLjbR5h0P9Z+HmIVDrfodSqhsPr/qZlroDws/3H2ZxHEO74wnHvK55NSyHieww/389DcatlVWBjEF5Xgy/tDFHBj0NHMM9vQdDddDo766g5XfVyv6xPjMGtNe/aEjR8Of8pnE0PNXYZuZZhiOo4oL3un+I6l5qBb4nYUT5bg1uO+xq9sH7Tt7daQAFcq7HvDItyao93cYAvLaHzG4WwZO4+lxb8DiLHy9yJoax+GXKHFAduH+95gUc3HCFzXs7gVLjTHLf2S3yzIiK98M/p+8NQAYtQPLA3tFvdGfjqoCuoT1cHejX2lSqzRBa2uH22fv6W6uDj8C19HwkVR8Bt4EpEW4ktu9HiN1jcisceYiSC4gPdmvmVzoWDk8nE8sd5fexBK7oBpB3alPqmOhmbpuCwhe6j3aOeJV09cCA4927/SZu5cUtxiCwpaHhdH10Orp9AsgGSqiICU+nzBHc12dOI1c5PKch+9xXtnB4diBUo7ErXtoil2WJEBi8QOKVsffsy6FDHATKVEvcMh5Ne0df5Ad+th8GHu/qcVKeBuD8iFXXaPbvADXQ16HD1dVAZjLRKcB9Q2Bb4Pk1G1WCevJ7RLGNXU6DhzL5qiBmV0O42gyH1508d9sAbAER8Wd3EoxRh5j1CmNI58QRDK8mmPoEYsup7rDcK3mQv8AVsDGFAcesC9HIkCIm0jMwb1zESVh7qxOF5jPOlfawfsdL1NuIWMxC9CTm0TOROJXHHHoDbZEqXNJTcxrz2/BKC1+Y2BFDv8A0Qx0vy39fgd9DcIBSH5HpcWmze5RbdVvei4orJ/O6XGb1efeHFA7qCYLa2cQ2DykXEe0HO67dBFdCAWk3h4Du8EVZsU91lmSl3xHejRxTXKR/AnV2RWg+wfEVWOG8S5VKmSLWn7kd4TD9x/7MQU6jXme0t4EHcchqKYr294YA0ru8ZxxKYnHxpELirhneTuTXGPMs7kv/WQTJQLWzf3O1Rx8Y/WWXO+0AbxyxZ/EACgKwV+Co761KlkkTQ2/M5gQyOtZ3Nze2KoreZfVZ7n7kv2ntUuLM7ZdT+kQBJSuYCWWnu/3OZwiclZvmcBVaCy/bUEHtAz/AHUeMV2auY3rH8w2f7PEC1d/rtKBdGAZPGZvCQtX8134lBkAlWOjlMOpzRL/AAp6B3gPY91EmKCuKg0W6iCtV+Sc/pcwYv2FwY3hlIam+I24nhFmoO6iVUPFixsjIftEXq6TENeUjLnzyyvZUCgNkCSHB2Ia3nvFNV+SDMx+ZCpW6giu+n/e81NFH6wUFCjvi+YrW5VqvZ95yYbHhIqCmSiCGLA2IMsJTeJUe3dIluvBObU8F/UpIMV4rEeA/Fx6XUzSZX0f1NzmCtIFUkaq9737oh2O4+w9vaIyLYNie0I+RjUuujKUJQK3bEDY45O4IAAV0BQBbwQeRPyXL+Nc9XfQT11C/GIIDS8yp5iXhgOG8bYzUrbKPK4f0gMTuCn7J/MQtFcJxFX+wEr2ioPIc27Hd9pdqdAX7H+IJgHxM9LnsfjZTn8NeudGlDspiIgGl8J030dRMG77wHpwzf8A3xMvaMF4ff8AkJQjGxRRzGYCxyXnnwRlxzoHYQ6UF1V9oFDo6jOsHlvLK9T6V6TmZwAF+Kv9fTUQaAkwaMy4XsYNL3vipThedge7fGIrbAjFbUb5lgpFmxRhFov2GE83qxXNU+1M+ZSQVaB5cBCrpK3dbivpPU79TmQ2OQwZUREeE36N4q5SvlWa1ui69swuaO+S/Wu8xJOW0F6cv7RJCaLmFx2O/iWwpWUMIFHGIXZcHCiJZdXzOX8VCk1ft3gU1kHlf1Xod/gdM36DqypXpoP9mfuHW6Hlmd86j33m0QjVdimn5ma2hlQNBgK+KhxKARaHC2UZGBCo5j9MkRScNNyyAgA27lGeZhrZXgV6+Ieh15QMQ9QG48PK4SKI3dflHXIdmYK9B0avYdow2NvnPl8wqLa1s7VV+8SsZlG3fLB8ybrG3myHmQtLcN1cww+PGJStBbwd47uh8nL+TNIetzuOK0tspO4xJAP9GmNQvdJmRULu9+cy8VDltvz0GO7l/DmOcFsdIceXP466by/DzKO2ZSdXS18ktgbv2B1EXgYH51+sG3BDXSm1fcV8sD/8m0mKtv8ABKuso5X3Xv6D13Fhror8Wm5XaJXA5BMKe639Gols7ZT+pR/Ul/VSirJyLfbAQDsDENTRXEI+vHV5oh6sem4iImUSXXjcQALoRxfkZs6oEod6j0/zUX3xLo3KssghFvFsF5f9idl4dPeGp6UUQdWe/qx6boubtDo76i/SYoBtYhQtL8wUxuBdUDmJCburD90gEAyhHswokgivPVqPNSzOmGrvQC+YbyjspYATg5qX591MCFWtvdmR2vubn7O44jm0NhwZK7mxgrWwSgKXK19xwyKJE1dqD4z2hpazPJd4W1e6y8+J6DX8zM/1+yzc34aZc75GvfE3PdBE8gfWuDlg16VouCcRQoIUlkeiC5oaQW2JXEQKrCS1pkabHtFjt1EDuLkj9iyvkQh8DFuwcBCrg0GvdHVJsZRQVvfmWcJGKXUDShBjvTdzENW0y4wqAB0V2JXttEKuTwmo1UXu0/OMzTv/AIHGcN4x7wt1mD7NYnyLY0U029o29wmIZK7A3RGIdIdDG+8nnodXUVLi5Ieqk9ZdMyuEhWRhRVOaUBrmAYXsgav2pKy+/mcsEJjeS7XtjL5oxg0wbb3DwthGwLa3rjfaOo1tHfioHmoJenCWvBS/EWaKiUOQDz3gczRKMTK5qD0GoUAcrKEfEkqgUdsOYAqtkyY46lDxxrsq3BoWWLldYSEQNg1QcxFLodS60TYXDXZQuXKi/u5V+N6h3Eqv0eg6aD8wwPVR2IUJVSyY8eIFfwuuCjYw1pHg6OA8QCq4lexGqqI937j6kVsAR/eHFnVEaaBde8Busx8vuIvQZtY3IUKCt1YYeGHYkfQBxKnEq/TloCrd3B6y8Sai07Azfd4jHt+AbPdRzM07KHE23DvXeUruWZmxXJSFq7MTAMVbS1VdV+sPBjSC3SuITV8HdRtvdQ59wwggxGVKFKLdm9S4Vkn2BXliVavRVCK283AUNGvPbz7QQgXcEO9MuTQJaHsoV8wnNoIl+3dcxThU32FCj5lvEaJWLB8cwr/FQZbtl2GoNluySmcdVK9pkuGKhh677C4B0Bp8ypiLPAAUw74iqTlbmX9mIeqTHaFUd6heGG00flM++7mWr/KJqpATEHkTHtkCKLVd4EMq0kLcR1EG2KwzqUolOApFv53BMPzBRTfnESJZBrXyebx2logQ7ANRgKKl5arRbaDy+bqFhmtcxVjfMwBHGq+e3Mw/IGtRbnZkByYcu0AQlHgrXLnPtNM7z1y3Y5YYfUdKLFNczfZ6wVdX2hchwAXgV0dtT5fc8n7lff7ja8ufeV7dAoAv7hRu35YrhSqCCVh4hhZiOyOTl3XiVOcEgGi+02vP3Pl9zLv9zBu37gvHVvQsqx75hA8Bo47DxEz0pV2huFDHp//Z`;

export const STATS_DATA: StatItem[] = [
  {
    id: 'autism',
    value: '+80',
    label: 'حالة ضمن طيف التوحد',
    sublabel: 'رعاية وتأهيل متخصص ومستمر',
  },
  {
    id: 'evaluation',
    value: '+50',
    label: 'حالة تقييم وتأخر نمائي',
    sublabel: 'متابعة شاملة وخطط علاجية فردية',
  },
  {
    id: 'learning-diff',
    value: '+40',
    label: 'حالة صعوبات تعلم وتربية',
    sublabel: 'دعم تعليمي وتدخل مبكر هادف',
  },
  {
    id: 'established',
    value: '2018',
    label: 'سنة التأسيس والانطلاق',
    sublabel: 'مسيرة عطاء ممتدة في عكار والشمال',
  },
];

export const WHY_IT_MATTERS = [
  {
    id: 'access',
    title: 'محدودية الخدمات المتخصصة',
    desc: 'ندرة المراكز المجهزة للعلاج والتأهيل في مناطق عكار والشمال مقارنة بحجم الاحتياج.',
    icon: 'MapPinOff',
    color: '#134A54',
  },
  {
    id: 'cost',
    title: 'ارتفاع كلفة الانتقال الشاقة',
    desc: 'توفير مشقة وتكاليف السفر اليومي المرهق للأهالي إلى المدن الكبرى كطرابلس وبيروت.',
    icon: 'Car',
    color: '#B9862F',
  },
  {
    id: 'early-intervention',
    title: 'أهمية التدخل المبكر والمنظّم',
    desc: 'السنوات الأولى من عمر الطفل تصنع الفارق الجوهري في تطور الدماغ واكتساب المهارات.',
    icon: 'Clock',
    color: '#2E93A0',
  },
  {
    id: 'family-support',
    title: 'مساندة وتوجيه الأسرة',
    desc: 'تمكين الوالدين بأدوات التعامل المنزلي والدعم النفسي لتخفيف الضغوط وتحقيق التوازن.',
    icon: 'HeartHandshake',
    color: '#6FAF52',
  },
];

export const WHO_WE_SERVE = [
  {
    id: 'autism',
    title: 'الأطفال ضمن طيف التوحد',
    desc: 'برامج فردية مكثفة لتطوير التواصل البصري واللفظي، وتعديل السلوك، وتنمية التفاعل الاجتماعي.',
    badge: 'طيف التوحد',
    icon: 'Sparkles',
    accent: '#2E93A0',
  },
  {
    id: 'special-needs',
    title: 'ذوو الاحتياجات الخاصة ومتلازمة داون',
    desc: 'رعاية شاملة تشمل التأهيل الذهني، الحركي، وتنمية مهارات الاعتماد على الذات في الحياة اليومية.',
    badge: 'التأخر النمائي ومتلازمة داون',
    icon: 'Heart',
    accent: '#6FAF52',
  },
  {
    id: 'learning-difficulties',
    title: 'أصحاب صعوبات التعلم والتركيز',
    desc: 'معالجة عسر القراءة والكتابة، تشتت الانتباه وفرط الحركة (ADHD)، وخطط التعليم الفردية الموجهة.',
    badge: 'صعوبات التعلم وADHD',
    icon: 'BookOpen',
    accent: '#E0A83E',
  },
  {
    id: 'dropouts',
    title: 'المتسرّبون أو المعرّضون للتسرّب المدرسي',
    desc: 'برامج استلحاق تربوي وسلوكي تعيد دمج الطفل في المسار التعليمي وتمنع الانقطاع عن الدراسة.',
    badge: 'الاستلحاق والدمج المدرسي',
    icon: 'GraduationCap',
    accent: '#D2665A',
  },
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'assessment',
    title: 'التقييم الشامل والمتابعة الدورية',
    shortDesc: 'تشخيص دقيق لقدرات الطفل النمائية واللغوية والذهنية ووضع خطة علاجية فردية متكاملة.',
    fullDesc: 'نستخدم بطاريات تقييم معيارية حديثة لتحديد نقاط القوة والاحتياجات النمائية لدى الطفل، مع بناء خطة تربوية فردية (IEP) ومراجعة دورية كل 3 أشهر لمتابعة التقدم ومشاركته مع الأهل.',
    iconName: 'ClipboardCheck',
    benefits: ['تقييم نمائي ومعرفي شامل', 'خطة تدخل فردية مرنة (IEP)', 'تقارير أداء دورية موثقة', 'جلسات تقييم مشترك مع الأسرة'],
    color: '#2E93A0',
  },
  {
    id: 'psycho-educational',
    title: 'الجلسات النفسية والتربوية المختصة',
    shortDesc: 'دعم نفسي وتربوي يعزز ثقة الطفل بنفسه ويساعده على تجاوز العقبات السلوكية والانفعالية.',
    fullDesc: 'جلسات بإشراف أخصائيين نفسيين وتربويين تركز على تنظيم المشاعر، تعديل السلوك، علاج القلق، وتطوير المهارات الأكاديمية والاجتماعية في بيئة محفزة وآمنة.',
    iconName: 'Brain',
    benefits: ['تعديل السلوك وتعزيز التركيز', 'علاج المشكلات الانفعالية والقلق', 'تنمية الثقة والاستقلالية', 'تأهيل الطفل للاندماج الصفي'],
    color: '#6FAF52',
  },
  {
    id: 'speech-therapy',
    title: 'علاج النطق واللغة والتواصل',
    shortDesc: 'تنمية مهارات التواصل اللفظي وغير اللفظي، وتصحيح مخارج الحروف، وتطوير الفهم اللغوي.',
    fullDesc: 'جلسات فردية متخصصة في علاج التأخر اللغوي، التأتأة، صعوبات البلع والنطق، مع استخدام وسائل التواصل البديل والمعزز (AAC) للأطفال غير الناطقين.',
    iconName: 'MessageSquareText',
    benefits: ['علاج التأخر اللغوي وعيوب النطق', 'تدريب على أساليب التواصل البديل (AAC)', 'تطوير الحصيلة اللغوية والسمعية', 'تمارين عضلات الفم والنطق'],
    color: '#E0A83E',
  },
  {
    id: 'occupational-therapy',
    title: 'العلاج الإشغالي والتكامل الحسي',
    shortDesc: 'تطوير المهارات اليومية والحركية الدقيقة والتوازن الحسي لتمكين الطفل من الاعتماد على نفسه.',
    fullDesc: 'تمارين نوعية لتقوية عضلات الأصابع واليدين، تدريب على ارتداء الملابس وتناول الطعام، مع غرفة تكامل حسي لمعالجة التحسس اللمسي، البصري، والسمعي.',
    iconName: 'Activity',
    benefits: ['تنمية المهارات الحركية الدقيقة', 'تنظيم المعالجة والتكامل الحسي', 'التدريب على رعاية الذات والاستقلالية', 'تحسين التناسق البصري الحركي'],
    color: '#134A54',
  },
  {
    id: 'parent-guidance',
    title: 'إرشاد الأهل والندوات التوعوية',
    shortDesc: 'لقاءات إرشادية وورش عمل للأهل لتوفير الدعم المعنوي وتدريبهم على استراتيجيات التعامل المنزلي.',
    fullDesc: 'نؤمن أن الأسرة شريك أساسي في العلاج؛ لذلك نقدم برامج دعم نفسي للأمهات والآباء، وندوات توعوية حول التوحد وصعوبات التعلم، ومجموعات دعم متبادل.',
    iconName: 'Users',
    benefits: ['استشارات أسرية دورية خاصة', 'ورش عمل تطبيقية للتعامل المنزلي', 'مجموعات دعم وتبادل خبرات للأهالي', 'توعية بحقوق ذوي الاحتياجات'],
    color: '#D2665A',
  },
  {
    id: 'recreational-activities',
    title: 'الأنشطة التربوية والترفيهية والدمج',
    shortDesc: 'أنشطة هادفة تنمي المهارات الاجتماعية والإبداعية وتدعم التعلم من خلال اللعب التفاعلي.',
    fullDesc: 'رحلات، ورش فنون ورسم، ومسرح وموسيقى علاجية تكسر العزلة وتبني جسور الصداقة والاندماج المجتمعي مع أقرانهم في جو مفعم بالفرح.',
    iconName: 'Smile',
    benefits: ['تعلم تفاعلي قائم على اللعب الهادف', 'فنون ورسم وأشغال يدوية علاجية', 'رحلات خارجية ومناسبات دمج', 'بناء الصداقات وتنمية العمل الجماعي'],
    color: '#2E93A0',
  },
  {
    id: 'physical-therapy',
    title: 'العلاج الفيزيائي والتأهيل الحركي',
    shortDesc: 'تحسين الحركة والتوازن والقوة الجسدية للأطفال ذوي الإعاقات الحركية عبر برامج متخصصة.',
    fullDesc: 'رعاية تأهيلية حركية متخصصة للأطفال الذين يعانون من الشلل الدماغي، ضمور العضلات، أو مشاكل التوازن والمشي، مع أجهزة مساعدة مصممة لراحتهم.',
    iconName: 'Zap',
    benefits: ['تحسين التوازن وتناسق المشي', 'تقوية العضلات ومنع التصلب الحركي', 'برامج تأهيل مخصصة لكل حالة', 'استخدام تقنيات تحفيز عصبي حركي'],
    color: '#1C6670',
    isWide: true,
  },
];

export const CURRENT_NEEDS: NeedItem[] = [
  {
    id: 'need-pt-room',
    title: 'تجهيز غرفة علاج فيزيائي متكاملة',
    desc: 'تأمين أجهزة تأهيل حركي، سلالم تمارين، وأسرّة طبية مخصصة لخدمة الأطفال ذوي الإعاقة الحركية والشلل الدماغي.',
    category: 'تجهيز طبي حركي',
    iconName: 'HeartPulse',
    targetCost: 'مساهمة مفتوحة أو تجهيز كامل',
    importance: 'أولوية قصوى لتخفيف معاناة الأطفال الحركية',
  },
  {
    id: 'need-elevator',
    title: 'تركيب مصعد كهربائي ملائم للكراسي',
    desc: 'توفير وسيلة وصول آمنة ومريحة وسهلة للأطفال والأهالي من ذوي الإعاقة الحركية للتنقل بين طوابق وأقسام المركز.',
    category: 'إمكانية الوصول والبيئة المهيأة',
    iconName: 'ArrowUpDown',
    targetCost: 'مساهمة مخصصة في المصعد',
    importance: 'حق أساسي للوصول المستقل والآمن',
  },
  {
    id: 'need-smartboards',
    title: 'ألواح تفاعلية وحواسيب للتعليم البصري',
    desc: 'أجهزة تفاعلية تدعم التعليم متعدد الحواس وتعزز سرعة استجابة أطفال التوحد وصعوبات التعلم للأنشطة المرئية.',
    category: 'تكنولوجيا التعليم والدمج',
    iconName: 'MonitorPlay',
    targetCost: 'لوح تفاعلي / حاسوب محمول',
    importance: 'تضاعف تفاعل الطفل وتركيزه 3 أضعاف',
  },
  {
    id: 'need-hvac',
    title: 'أجهزة تكييف وتدفئة ملائمة للصفوف',
    desc: 'تأمين بيئة حرارية مريحة ومستقرة للأطفال على مدار فصول السنة، خصوصاً في فصول الشتاء القاسية بعكار.',
    category: 'البيئة والراحة المادية',
    iconName: 'SunSnow',
    targetCost: 'وحدات تكييف وتدفئة',
    importance: 'حماية صحة الأطفال واستمرار الجلسات شتاءً',
  },
  {
    id: 'need-ramp',
    title: 'تأهيل المدخل والمنحدر الحركي الآمن',
    desc: 'بناء منحدر قياسي (Ramp) مع حواجز وسقالة أمان تضمن سلامة دخول الكراسي المتحركة وعربات الأطفال.',
    category: 'السلامة والأمان الخارجي',
    iconName: 'ShieldCheck',
    targetCost: 'تأهيل كامل للمدخل',
    importance: 'معايير أمان معتمدة تمنع مخاطر الانزلاق',
  },
  {
    id: 'need-flooring',
    title: 'أرضيات مبطّنة وممتصة للصدمات',
    desc: 'فرش الصفوف وغرف الجلسات بأرضيات أمان إسفنجية ومضادة للبكتيريا لحماية الأطفال أثناء الحركة واللعب الحسي.',
    category: 'الأمان الداخلي والصحي',
    iconName: 'Grid',
    targetCost: 'متر مربع إسفنجي آمن',
    importance: 'بيئة آمنة تماماً للأطفال كثيري الحركة',
  },
];

export const BRANCHES_DATA: BranchInfo[] = [
  {
    id: 'minyeh',
    name: 'فرع المنية (المركز الإقليمي)',
    coverage: 'يخدم المنطقة الحيوية الممتدة من طرابلس وحتى العبدة ومحيطها.',
    phones: ['76801069', '0096176801069'],
    locationDesc: 'المنية — الشارع الرئيسي — سهولة وصول ومواقف متوفرة',
    workingHours: 'من الإثنين إلى الجمعة: 8:00 صباحاً – 3:00 بعد الظهر',
  },
  {
    id: 'halba',
    name: 'فرع حلبا — عكار (المقر الرئيسي)',
    coverage: 'يخدم كافة بلدات وقرى عكار، الدريب، الجومة، والسهل.',
    phones: ['78913443', '70120915', '26695920'],
    locationDesc: 'حلبا — عكار — مبنى الجمعية — مساحة 300 م² مجهزة',
    workingHours: 'من الإثنين إلى السبت: 8:00 صباحاً – 3:30 بعد الظهر',
  },
];

export const GALLERY_DATA: GalleryItem[] = [
  {
    id: 'g1',
    title: 'قاعات التعليم الفردي والجلسات الخاصة',
    category: 'therapy',
    desc: 'غرف مصممة لعزل المشتتات وتركيز انتباه الطفل مع الأخصائي المعالج.',
    imageUrl: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80',
    tag: 'جلسات فردية',
  },
  {
    id: 'g2',
    title: 'الركن الحسي وغرفة التكامل التفاعلية',
    category: 'sensory',
    desc: 'إضاءات هادئة وأدوات حسية لتنظيم الاستثارة العصبية لدى أطفال التوحد.',
    imageUrl: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=800&q=80',
    tag: 'تكامل حسي',
  },
  {
    id: 'g3',
    title: 'الأنشطة الجماعية والألعاب التفاعلية',
    category: 'activities',
    desc: 'تنمية روح المشاركة واللعب الجماعي والتواصل البصري والاجتماعي.',
    imageUrl: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?auto=format&fit=crop&w=800&q=80',
    tag: 'أنشطة جماعية',
  },
  {
    id: 'g4',
    title: 'ورش الفنون والرسم والتعبير الإبداعي',
    category: 'activities',
    desc: 'استخدام الألوان والأشكال لتطوير التعبير غير اللفظي وتفريغ الطاقات الإيجابية.',
    imageUrl: 'https://images.unsplash.com/photo-1596495578065-6e0763fa1178?auto=format&fit=crop&w=800&q=80',
    tag: 'فنون وعلاج بالرسم',
  },
  {
    id: 'g5',
    title: 'مساحات اللعب الحركي والتوازن الآمن',
    category: 'facilities',
    desc: 'أرضيات مبطنة ومعدات أمان تتيح للطفل تفريغ طاقته الحركية بثقة.',
    imageUrl: 'https://images.unsplash.com/photo-1516627145497-ae6968895b74?auto=format&fit=crop&w=800&q=80',
    tag: 'مرافق آمنة',
  },
  {
    id: 'g6',
    title: 'قاعات التدريب التربوي وعلاج النطق',
    category: 'therapy',
    desc: 'مرايا نطق وبطاقات تواصل بصرية حديثة لتسريع اكتساب الكلمات والمفاهيم.',
    imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80',
    tag: 'علاج نطق',
  },
];

export const DONATION_TIERS: SupportOption[] = [
  {
    id: 'session',
    title: 'كفالة جلسات علاجية لطفل',
    suggestedAmount: '25 $',
    impactNote: 'تغطي جلسة نطق أو علاج نفسي أو وظيفي لطفل غير قادر على تحمل التكاليف.',
    iconName: 'Sparkle',
  },
  {
    id: 'monthly',
    title: 'كفالة رعاية شهرية شاملة',
    suggestedAmount: '120 $',
    impactNote: 'تضمن استمرار الطفل في الصف التربوي والجلسات الفردية لمدة شهر كامل.',
    iconName: 'CalendarCheck',
  },
  {
    id: 'annual',
    title: 'كفالة سنوية كاملة لطفل',
    suggestedAmount: '1200 $',
    impactNote: 'تغطي العام التأهيلي والتربوي كاملاً مع التقييمات والمتابعة الأسرية المستمرة.',
    iconName: 'Award',
  },
  {
    id: 'equipment',
    title: 'المساهمة في التجهيزات والمصعد',
    suggestedAmount: 'مبلغ مخصص',
    impactNote: 'تساهم مباشرة في شراء أجهزة العلاج الفيزيائي أو تمويل مصعد الأمان والألواح الذكية.',
    iconName: 'Layers',
  },
  {
    id: 'open',
    title: 'مساهمة مفتوحة في التشغيل العام',
    suggestedAmount: 'أي مبلغ',
    impactNote: 'كل مساهمة مهما صغرت تدعم تدفئة الصفوف، المواد التعليمية، ورواتب الأخصائيين.',
    iconName: 'HeartHandshake',
  },
];

export const TRUST_AND_TRANSPARENCY = [
  {
    id: 't1',
    title: 'تقارير أثر ومتابعة منتظمة',
    desc: 'نرسل لكل كفيل وداعم ملخصاً دورياً عن التقدم الإيجابي الذي حققه الطفل أو المشروع المدعوم.',
    icon: 'FileText',
  },
  {
    id: 't2',
    title: 'توثيق رسمي وإيصالات معتمدة',
    desc: 'توثيق كل مساهمة بإيصال مالي رسمي أو كتاب شكر تقديري صادر عن الجمعية.',
    icon: 'Receipt',
  },
  {
    id: 't3',
    title: 'إمكانية تخصيص الدعم لبند محدد',
    desc: 'حرية كاملة للداعم في توجيه مساهمته إلى طفل بعينه، أو جهاز محدد، أو تجهيز مرفق.',
    icon: 'Target',
  },
  {
    id: 't4',
    title: 'صيانة كاملة لخصوصية وكرامة الأطفال',
    desc: 'نلتزم بأعلى معايير حماية الطفل؛ لا يتم نشر أي صور أو مقاطع إلا بموافقة خطية صريحة من الأهل.',
    icon: 'Lock',
  },
];

export const FAQ_DATA: FAQItem[] = [
  {
    id: 'f1',
    category: 'general',
    question: 'ما هو مركز CALD وما هي جمعية النعمانية؟',
    answer: 'مركز CALD (Center for Autism and Learning Disabilities) هو الصرح التخصصي التابع لجمعية النعمانية في عكار والشمال، تأسس عام 2018 لتقديم خدمات شاملة لأطفال التوحد وصعوبات التعلم ومتلازمة داون وتأهيل أسرهم.',
  },
  {
    id: 'f2',
    category: 'registration',
    question: 'كيف يمكنني تسجيل طفلي للتقييم أو الجلسات؟',
    answer: 'يمكنك التواصل مباشرة مع فروعنا في حلبا أو المنية عبر الأرقام الموضحة، أو الضغط على زر "حجز تقييم أولي" في الموقع لتحديد موعد مقابلة وتشخيص مع فريقنا المختص.',
  },
  {
    id: 'f3',
    category: 'sponsorship',
    question: 'كيف يمكنني التبرع أو كفالة طفل من خارج لبنان؟',
    answer: 'نستقبل المساهمات عبر التحويلات المباشرة، ويتم تزويد الداعم بوصل رسمي وتقارير متابعة دورية عن حالة الطفل المكفول مع صيانة خصوصيته التامة.',
  },
  {
    id: 'f4',
    category: 'services',
    question: 'ما هي الفئات العمرية التي يستقبلها المركز؟',
    answer: 'نستقبل الأطفال بدءاً من سن التدخل المبكر (سنتين وما فوق) وحتى مرحلة المراهقة والدمج الأكاديمي والمهني.',
  },
  {
    id: 'f5',
    category: 'general',
    question: 'أين تقع فروع المركز في الشمال؟',
    answer: 'لدينا المقر الرئيسي في حلبا - عكار (مساحة 300 م² تشمل صفوفاً وملاعب وغرف علاج)، بالإضافة إلى فرعنا الجديد في المنية لخدمة أبناء المنية وطرابلس والسهل.',
  },
];
